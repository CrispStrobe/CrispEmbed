// crispembed server — HTTP API for embeddings, OCR, face, NER, layout.
//
// Usage: crispembed-server -m model.gguf [--port 8080] [--host 0.0.0.0]
//
// Endpoints:
//   POST /systemone       — full publisher joint-schema request/response
//   POST /decide          — calibrated typed answers for state + schema
//   POST /tokens          — raw or normalized per-token features and IDs
//   POST /masked-logits   — raw tied masked-LM logits and positions
//   POST /fill-mask       — decoded top-k mask predictions
//   POST /embed           — {"texts": ["hello"]} → {"embeddings": [[...]]}
//   POST /v1/embeddings   — OpenAI-compatible embedding API
//   POST /api/embed       — Ollama-compatible (batch)
//   POST /api/embeddings  — Ollama-compatible (single, legacy)
//   POST /math/ocr        — {"image": "formula.png"} → {"text": "...", "ms": M}
//   POST /ocr             — {"image": "doc.png"} → {"results": [...], "ms": M}
//   POST /ocr/pipeline    — {"image": "doc.png"} → full orchestrator (routing+cleanup+gate)
//   POST /layout/detect   — {"image": "page.png"} → {"regions": [...]}
//   POST /text/detect     — {"image": "page.png"} → {"regions": [...]}
//   POST /detect          — {"image": "face.jpg"} → face detection
//   POST /face            — {"image": "face.jpg"} → face embedding
//   POST /vit/encode      — {"image": "img.jpg"} → ViT embedding
//   POST /pix2struct/generate — {"image": "doc.png", "max_tokens": 256} → {"text": "...", "ms": M}
//   POST /clip/text       — {"text": "query"} → CLIP text embedding
//   POST /colbert/score   — {"query": "...", "documents": [...]} → ColBERT scoring
//   POST /ner/extract     — {"text": "...", "labels": [...]} → NER entities
//   POST /scan/cleanup    — {"image": "scan.png"} → cleaned image
//   POST /scan/split      — {"image": "scan.png"} → {"pages":1|2,"split_x":X}
//   POST /scan/content    — {"image": "scan.png"} → {"content":true,"x0":..,"y1":..}
//   POST /pdf/dpi              — {"file": "path.pdf"} → per-page DPI info
//   POST /preprocess/skew      — {"image": "..."} → {"angle": F, "confidence": F}
//   POST /preprocess/dewarp    — {"image": "...", "output": "..."} → PGM image or JSON
//   POST /preprocess/cc-detect — {"image": "..."} → {"regions": [...]}
//   POST /render/ocr           — {"results": [...], "format": "hocr"} → rendered document
//   POST /ocr/document         — multi-page OCR: images → searchable PDF / hOCR / text
//   GET  /health          — server status + loaded capabilities

#include "crispembed.h"
#include "moedern_text_api.h"
#include "core/token_utf8.h"
#include <algorithm>
#include <numeric>
#include "core/json.h"
#include "core/env_gate.h"
#include "core/gguf_loader.h"
#include "ocr_render.h"
#include "scan_cleanup.h"
#include "core/image_out.h"
#include "core/temp_file.h"
#include "model_mgr.h"
#include "pdf_info.h"
#if __has_include("text_lid_dispatch.h")
#include "text_lid_dispatch.h"
#define SERVER_HAS_LID 1
#else
#define SERVER_HAS_LID 0
#endif
#include "httplib.h"

// stb_image for /math/ocr image loading
#define STB_IMAGE_STATIC
#define STB_IMAGE_IMPLEMENTATION
#include "../../ggml/examples/stb_image.h"

#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <filesystem>
#include <iomanip>
#include <limits>
#include <system_error>

#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif
#include <mutex>
#include <sstream>
#include <string>
#include <vector>

using core_json::json_escape;
using core_json::json_extract_number;
using core_json::json_extract_strings;

// --- Request image paths -------------------------------------------------
//
// Every image-taking endpoint reads its input by SERVER-SIDE path: the client
// sends {"image": "/path/on/the/server"}. That is convenient for a local tool
// and an arbitrary-file-read primitive for a reachable one — worst on /face,
// which turns any readable image into a biometric template.
//
// --image-root confines those reads to one subtree. Unset, behaviour is
// unchanged (any readable path), which is the historical default and fine on
// loopback. Set, a path outside the root is rejected before it reaches any
// model, and the handler sees an empty path — which every endpoint already
// treats as a 400 — so confinement fails closed without needing 30 handlers
// to grow a new error branch.
static std::string g_image_root; // empty = unrestricted
static std::string g_model_root; // empty = unrestricted

static bool path_within(const std::string & path, const std::string & root) {
    if (root.empty()) return true;
    if (path.empty()) return false;

    std::error_code ec;
    // weakly_canonical resolves .. and symlinks, so neither a traversal nor a
    // symlink planted inside the root can escape it.
    const std::filesystem::path resolved = std::filesystem::weakly_canonical(path, ec);
    if (ec) return false;
    const std::filesystem::path base = std::filesystem::weakly_canonical(root, ec);
    if (ec) return false;

    // Component-wise, not string-prefix: /srv/scansEVIL must not pass for a
    // root of /srv/scans.
    auto r = base.begin();
    auto p = resolved.begin();
    for (; r != base.end(); ++r, ++p) {
        if (p == resolved.end() || *p != *r) return false;
    }
    return true;
}

// Parse a path-valued field and confine it.
//
// Every endpoint here reads its input by SERVER-SIDE path, which is convenient
// for a local tool and an arbitrary-filesystem primitive for a reachable one.
// `--image-root` originally covered only {"image": ...}; three other fields
// bypassed it, and two were worse than the read it was written for:
//
//   "output"  /preprocess/dewarp   — fopen("wb"), i.e. arbitrary file WRITE
//   "model"   /preprocess/tps-dewarp — loaded as a GGUF and EXECUTED as a graph
//   "file"    /pdf/dpi             — arbitrary read
//
// Returns "" when absent or out of bounds; every endpoint already treats an
// empty path as a 400, so confinement fails closed without new error branches.
// The reason goes to stderr, not the response: an unauthenticated caller must
// not learn whether a path exists.
//
// The field is read through core_json's depth-1 finder, not a bare
// body.find("\"key\""). A nested decoy — {"meta":{"image":"/a"},"image":"/b"} —
// makes a naive scan take the first textual hit while a validating proxy in
// front reads the real top-level field, so the two disagree about which path
// was requested. Matching the same finder every other field read uses keeps
// confinement and parsing aligned on one notion of "the image field".
static std::string extract_path_field(const std::string & body, const char * key, const std::string & root,
                                      const char * root_flag) {
    std::vector<std::string> vals;
    json_extract_strings(body, key, vals);
    if (vals.empty()) return "";

    std::string path = vals.front();
    if (path.empty()) return "";
    if (!path_within(path, root)) {
        fprintf(stderr, "crispembed-server: rejected '%s' path outside %s (%s): %s\n", key, root_flag, root.c_str(),
                path.c_str());
        return "";
    }
    return path;
}

// Preserve context-owned outputs until serialization completes, under the same
// lock as pooled embeddings. Fill-mask and full logits share one inference path.
static void handle_encoder_request(const httplib::Request & req, httplib::Response & res, crispembed_context * ctx,
                                   std::mutex & model_mutex, int mode) {
    auto error = [&](int status, const char * message) {
        res.status = status;
        res.set_content("{\"error\":\"" + json_escape(message) + "\"}", "application/json");
    };
    if (!ctx) return error(503, "no embedding model loaded");
    if (mode && !crispembed_has_masked_lm(ctx)) return error(400, "loaded model has no masked LM head");
    std::vector<std::string> texts;
    if (json_extract_strings(req.body, "text", texts) != 1 || texts.front().empty())
        return error(400, "provide one nonempty text field");
    const std::string original = texts.front();
    if (original.find('\0') != std::string::npos) return error(400, "text contains embedded NUL");
    std::string text = original;
    if (mode) {
        size_t at = 0;
        while ((at = text.find("[MASK]", at)) != std::string::npos) {
            text.replace(at, 6, "<|mask|>");
            at += 8;
        }
    }
    const double requested_k = json_extract_number(req.body, "top_k", 5);
    if (mode == 2 &&
        (!std::isfinite(requested_k) || requested_k < 1 || requested_k > 100 || std::floor(requested_k) != requested_k))
        return error(400, "top_k must be an integer from 1 to 100");
    const bool normalize = core_json::json_extract_bool(req.body, "normalize", false);
    std::lock_guard<std::mutex> lock(model_mutex);
    int rows = 0, dim = 0;
    const int32_t * positions = nullptr;
    const float * data = mode        ? crispembed_masked_logits(ctx, text.c_str(), &rows, &dim, &positions)
                         : normalize ? crispembed_encode_tokens(ctx, text.c_str(), &rows, &dim)
                                     : crispembed_encode_tokens_raw(ctx, text.c_str(), &rows, &dim);
    if (!data || rows <= 0 || dim <= 0)
        return error(400, mode ? "text requires a mask token" : "token encoding failed");
    const int32_t * ids = mode ? positions : crispembed_last_token_ids(ctx);
    if (!ids) return error(500, "token positions unavailable");
    std::ostringstream js;
    js << std::setprecision(9) << "{\"text\":\"" << json_escape(original) << "\",";
    if (mode != 2) {
        js << (mode ? "\"positions\":[" : "\"token_ids\":[");
        for (int r = 0; r < rows; ++r) js << (r ? "," : "") << ids[r];
        js << "]," << (mode ? "\"vocab\":" : "\"dim\":") << dim;
        if (!mode) js << ",\"normalized\":" << (normalize ? "true" : "false");
        js << (mode ? ",\"logits\":[" : ",\"embeddings\":[");
        for (int r = 0; r < rows; ++r) {
            js << (r ? ",[" : "[");
            for (int c = 0; c < dim; ++c) {
                const float value = data[(size_t)r * dim + c];
                if (!std::isfinite(value)) return error(500, "nonfinite encoder output");
                js << (c ? "," : "") << value;
            }
            js << "]";
        }
        js << "]}";
    } else {
        js << "\"masks\":[";
        for (int r = 0; r < rows; ++r) {
            const float * logits = data + (size_t)r * dim;
            for (int c = 0; c < dim; ++c)
                if (!std::isfinite(logits[c])) return error(500, "nonfinite masked logits");
            std::vector<int> order(dim);
            std::iota(order.begin(), order.end(), 0);
            const int k = std::min((int)requested_k, dim);
            std::partial_sort(order.begin(), order.begin() + k, order.end(),
                              [&](int a, int b) { return logits[a] == logits[b] ? a < b : logits[a] > logits[b]; });
            const double maximum = logits[order[0]];
            double denominator = 0;
            for (int c = 0; c < dim; ++c) denominator += std::exp((double)logits[c] - maximum);
            js << (r ? "," : "") << "{\"position\":" << positions[r] << ",\"predictions\":[";
            for (int j = 0; j < k; ++j) {
                const int id = order[j];
                int size = 0;
                const char * bytes = crispembed_token_bytes(ctx, id, &size);
                const auto token = core_utf8::token_utf8_lossy(bytes ? bytes : "", size);
                js << (j ? "," : "") << "{\"token_id\":" << id << ",\"token\":\"" << json_escape(token)
                   << "\",\"logit\":" << logits[id]
                   << ",\"score\":" << std::exp((double)logits[id] - maximum) / denominator << "}";
            }
            js << "]}";
        }
        js << "]}";
    }
    res.set_content(js.str(), "application/json");
}

// ---------------------------------------------------------------------------
// Rerank (issue #37 native shape, issue #51 Cohere/Jina shape)
//
// Both routes run the SAME scoring path and differ only in how the request is
// parsed and the response is spelled, so they share one implementation. The
// alternative — a second copy of the handler — is the "two copies drift" defect
// core_json itself exists to undo.
//
//   POST /rerank      native.  {"query","documents":[str],"top_n"}
//                     -> {"query", "results":[{index, score, document}]}
//                     `score` is the RAW classifier logit, unbounded.
//
//   POST /v1/rerank   the de-facto Cohere / Jina schema, so crispembed-server
//                     drops into LiteLLM / LlamaIndex / LangChain / llama-swap
//                     without an adapter.
//                     {"model","query","documents":[str] | [{"text":str}],
//                      "top_n","return_documents"}
//                     -> {"id","model","object","results":[{index,
//                         relevance_score, document?:{text}}],"meta"}
//
// Two deliberate differences on /v1/rerank:
//
// (a) `relevance_score` is sigmoid(logit), i.e. 0..1, because that is what the
//     Cohere/Jina clients document and what their score thresholds assume. The
//     sigmoid is strictly monotonic, so the RANKING — the thing a reranker is
//     for — is identical to /rerank's; only the scale changes. Set
//     CRISPEMBED_SERVER_RERANK_RAW_SCORES=1 to emit the raw logit there too
//     (for a model whose head is already calibrated, or to compare the two
//     routes number-for-number). Never removed: it is the A/B gate for this
//     transform.
//
// (b) `document` is omitted unless "return_documents": true, matching Cohere's
//     documented default. Clients that need the text either ask for it or index
//     back into the array they sent.
//
// No `usage` / token counts are emitted: the pair-encoder path exposes no token
// count, and inventing a plausible one would be worse than leaving the optional
// field out.
static void handle_rerank_request(const httplib::Request & req, httplib::Response & res, crispembed_context * ctx,
                                  std::mutex & model_mutex, const std::string & model_name, bool cohere_shape) {
    const char * route = cohere_shape ? "/v1/rerank" : "/rerank";
    if (!ctx) {
        res.status = 503;
        res.set_content("{\"error\": \"no embedding model loaded\"}", "application/json");
        return;
    }
    if (!crispembed_is_reranker(ctx)) {
        res.status = 400;
        res.set_content("{\"error\": \"loaded model is not a cross-encoder reranker\"}", "application/json");
        return;
    }

    std::string query_text;
    {
        std::vector<std::string> q;
        if (json_extract_strings(req.body, "query", q) > 0) query_text = q.front();
    }
    if (query_text.empty()) {
        res.status = 400;
        res.set_content("{\"error\": \"missing query field\"}", "application/json");
        return;
    }

    std::vector<std::string> doc_texts;
    if (cohere_shape) {
        // Accepts ["a","b"] and [{"text":"a"},{"text":"b"}] alike.
        core_json::json_extract_documents(req.body, "documents", doc_texts);
    } else {
        json_extract_strings(req.body, "documents", doc_texts);
    }
    if (doc_texts.empty()) {
        res.status = 400;
        res.set_content("{\"error\": \"no documents provided\"}", "application/json");
        return;
    }
    const int top_n = (int)json_extract_number(req.body, "top_n", 0);
    // Cohere's default is false; the caller already holds the documents it sent.
    const bool return_documents = cohere_shape && core_json::json_extract_bool(req.body, "return_documents", false);

    std::lock_guard<std::mutex> lock(model_mutex);
    auto t0 = std::chrono::steady_clock::now();

    // Batch rerank (caches the classifier weights → avoids a per-document
    // GPU→CPU transfer; see crispembed_rerank_batch).
    std::vector<const char *> doc_ptrs;
    doc_ptrs.reserve(doc_texts.size());
    for (const auto & d : doc_texts) doc_ptrs.push_back(d.c_str());
    std::vector<float> scores(doc_texts.size(), 0.0f);
    const int n_scored =
        crispembed_rerank_batch(ctx, query_text.c_str(), doc_ptrs.data(), (int)doc_ptrs.size(), scores.data());
    if (n_scored != (int)doc_texts.size()) {
        res.status = 500;
        res.set_content("{\"error\": \"rerank failed\"}", "application/json");
        return;
    }

    std::vector<std::pair<size_t, float>> ranked;
    ranked.reserve(doc_texts.size());
    for (size_t i = 0; i < doc_texts.size(); ++i) {
        if (std::isfinite(scores[i])) ranked.emplace_back(i, scores[i]);
    }
    std::sort(ranked.begin(), ranked.end(), [](const auto & a, const auto & b) { return a.second > b.second; });
    if (top_n > 0 && (int)ranked.size() > top_n) ranked.resize(top_n);

    double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
    std::ostringstream js;
    if (cohere_shape) {
        // Read once: a per-request getenv in a served path is pointless work.
        static const bool raw_scores = core_env::on("CRISPEMBED_SERVER_RERANK_RAW_SCORES");
        static std::atomic<uint64_t> rerank_seq{ 0 };
        js << "{\"id\": \"rerank-" << rerank_seq.fetch_add(1) << "\", \"model\": \"" << json_escape(model_name)
           << "\", \"object\": \"list\", \"results\": [";
        for (size_t i = 0; i < ranked.size(); ++i) {
            if (i > 0) js << ", ";
            const float logit = ranked[i].second;
            const double rel = raw_scores ? (double)logit : 1.0 / (1.0 + std::exp(-(double)logit));
            // 9 dp, not the native route's 6: a confident cross-encoder logit
            // of ~+15 saturates sigmoid past 0.9999995, so at 6 dp several top
            // hits all print "1.000000" and a client that re-sorts by score
            // loses the ordering this route just computed. 9 dp keeps them
            // distinct over the logit range these heads actually produce.
            js << "{\"index\": " << ranked[i].first << ", \"relevance_score\": " << std::fixed << std::setprecision(9)
               << rel;
            if (return_documents) {
                js << ", \"document\": {\"text\": \"" << json_escape(doc_texts[ranked[i].first]) << "\"}";
            }
            js << "}";
        }
        js << "], \"meta\": {\"api_version\": {\"version\": \"2\"}, \"billed_units\": {\"search_units\": 1}}}";
    } else {
        js << "{\"query\": \"" << json_escape(query_text) << "\", \"results\": [";
        for (size_t i = 0; i < ranked.size(); ++i) {
            if (i > 0) js << ", ";
            js << "{\"index\": " << ranked[i].first << ", \"score\": " << std::fixed << std::setprecision(6)
               << ranked[i].second << ", \"document\": \"" << json_escape(doc_texts[ranked[i].first]) << "\"}";
        }
        js << "]}";
    }
    fprintf(stderr, "crispembed-server: %s %zu docs in %.1f ms\n", route, doc_texts.size(), ms);
    res.set_content(js.str(), "application/json");
}

static std::string extract_image_path(const std::string & body) {
    return extract_path_field(body, "image", g_image_root, "--image-root");
}

// Encode a processed image for a JSON response.
//
// These endpoints used to base64 RAW RGB bytes straight into the payload, so
// twelve of them — every super-resolution and restoration engine, i.e. exactly
// the ones POLICY.md §5 is about because they SYNTHESISE detail — returned
// completely unmarked AI-processed images. Going through core_imgout means the
// bytes are a PNG carrying the provenance chunk (and a C2PA manifest when a
// signing identity is configured), the same as the CLI.
//
// `out_format` tells the client what it actually got: "png" normally, "raw"
// under CRISPEMBED_IMAGE_FORMAT=ppm, which stays available for callers that
// were consuming raw RGB and are not ready to decode.
static std::string encode_image_b64(const uint8_t * data, int w, int h, int comp, const char * engine,
                                    std::string & out_format) {
    static const char * b64chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

    std::string bytes;
    if (core_imgout::want_ppm()) {
        bytes.assign(reinterpret_cast<const char *>(data), (size_t)w * h * comp);
        out_format = "raw";
    } else {
        std::string mime;
        if (!core_imgout::emit_to_string(bytes, mime, data, w, h, comp, engine)) {
            bytes.assign(reinterpret_cast<const char *>(data), (size_t)w * h * comp);
            out_format = "raw";
        } else {
            out_format = "png";
        }
    }

    const size_t n_bytes = bytes.size();
    const uint8_t * src = reinterpret_cast<const uint8_t *>(bytes.data());
    std::string b64;
    b64.reserve(((n_bytes + 2) / 3) * 4);
    for (size_t i = 0; i < n_bytes; i += 3) {
        uint32_t v = (uint32_t)src[i] << 16;
        if (i + 1 < n_bytes) v |= (uint32_t)src[i + 1] << 8;
        if (i + 2 < n_bytes) v |= (uint32_t)src[i + 2];
        b64 += b64chars[(v >> 18) & 0x3f];
        b64 += b64chars[(v >> 12) & 0x3f];
        b64 += (i + 1 < n_bytes) ? b64chars[(v >> 6) & 0x3f] : '=';
        b64 += (i + 2 < n_bytes) ? b64chars[v & 0x3f] : '=';
    }
    return b64;
}

// Private temp files: see core/temp_file.h. Uploaded pages used to go to a
// guessable /tmp/crispembed_doc_<pid>_<n>.img opened with fopen("wb") —
// symlink-redirectable and world-readable, holding the document being OCR'd.
static std::string make_private_temp_file(const char * suffix) {
    return core_tmp::make_private(suffix);
}

static bool write_rotated_ppm(const char * path, const uint8_t * rgb, int w, int h, int angle) {
    if (!path || !rgb || w <= 0 || h <= 0) return false;
    const int out_w = (angle == 90 || angle == 270) ? h : w;
    const int out_h = (angle == 90 || angle == 270) ? w : h;
    std::vector<uint8_t> rotated((size_t)out_w * out_h * 3);
    for (int y = 0; y < h; y++) {
        for (int x = 0; x < w; x++) {
            int ox = x, oy = y;
            if (angle == 90) {
                ox = h - 1 - y;
                oy = x;
            } else if (angle == 180) {
                ox = w - 1 - x;
                oy = h - 1 - y;
            } else if (angle == 270) {
                ox = y;
                oy = w - 1 - x;
            }
            memcpy(rotated.data() + ((size_t)oy * out_w + ox) * 3, rgb + ((size_t)y * w + x) * 3, 3);
        }
    }
    FILE * f = fopen(path, "wb");
    if (!f) return false;
    const bool ok = core_imgout::emit(f, rotated.data(), out_w, out_h, 3, "autorotate");
    fclose(f);
    return ok;
}

int main(int argc, char ** argv) {
    std::string model_path;
    std::string systemone_model_path;
    std::string moedern_model_path;
    std::string host = "127.0.0.1";
    std::string det_model_path;       // face detection model
    std::string rec_model_path;       // face recognition model
    bool accept_biometric = false;    // --accept-biometric: ack face-recognition use
    std::string vit_model_path;       // standalone ViT model (SigLIP/CLIP)
    std::string clip_text_model_path; // CLIP text encoder
    std::string ocr_model_path;       // math OCR model (PP-FormulaNet, HMER, BTTR, PosFormer, etc.)
    std::string marker_model_path, marker_pdfium_path;
    int marker_mode = 0;
    bool marker_enabled = false;
    std::string ocr_det_model_path;   // general OCR: text detection model (DBNet)
    std::string ocr_rec_model_path;   // general OCR: text recognition model (TrOCR)
    std::string ocr_engine_name;      // --ocr-engine: explicit orchestrator engine (CLI parity)
    std::string ocr_cls_model_path;   // --ocr-cls: optional PP-LCNet 0/180 line-orientation classifier
    std::string layout_model_path;    // layout detection model (RT-DETRv2)
    std::string table_model_path;     // table cell OCR model (Tesseract-LSTM GGUF)
    std::string formula_model_path;   // formula OCR model (PP-FormulaNet GGUF)
    bool route_tables = false;
    bool route_formulas = false;
    std::string text_det_model_path;   // surya text detection model
    std::string ner_model_path;        // NER model (GLiNER)
    std::string lid_model_path;        // text LID model
    bool enable_ocr_orch = false;      // --ocr-pipeline: enable orchestrator endpoint
    int ocr_max_tokens = 0;            // --ocr-max-tokens N (0 = engine default)
    int server_dim = 0;                // --dim N: default Matryoshka truncation (0 = native)
    std::string ocr_prompt;            // --ocr-prompt TEXT ("" = engine default)
    std::string vlm_model_path;        // VLM escalation model for orchestrator
    int vlm_engine = 0;                // 0=GOT, 1=GLM, 2=Qwen2-VL(+PaddleOCR-VL), 3=InternVL2
    std::string punct_model_path;      // punct restoration model for orchestrator
    std::string sr_model_path;         // text super-resolution model (--sr-model)
    std::string pan_model_path;        // PAN super-resolution model (--pan-model)
    std::string sam2_model_path;       // SAM 2.1 segmentation model (--sam2-model)
    std::string hat_model_path;        // HAT super-resolution model (--hat-model)
    std::string dat_model_path;        // DAT super-resolution model (--dat-model)
    std::string safmn_model_path;      // SAFMN super-resolution model (--safmn-model)
    std::string esrgan_model_path;     // Real-ESRGAN super-resolution model (--esrgan-model)
    std::string swinir_model_path;     // SwinIR super-resolution model (--swinir-model)
    std::string tbsrn_model_path;      // TBSRN text-line SR model (--tbsrn-model)
    std::string restormer_model_path;  // Restormer restoration model (--restormer-model)
    std::string scunet_model_path;     // SCUNet denoising model (--scunet-model)
    std::string instructir_model_path; // InstructIR restoration model (--instructir-model)
    std::string adair_model_path;      // AdaIR restoration model (--adair-model)
    std::string pix2struct_model_path; // Pix2Struct document understanding model (--pix2struct)
    int port = 8080;
    // 0 = the C API's documented auto default, min(4, cores) — the server had
    // the same blanket single-thread default the CLI shipped in v0.17.7
    // (issue #45); an explicit -t still wins, including -t 1.
    int n_threads = 0;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-m") == 0 && i + 1 < argc)
            model_path = argv[++i];
        else if (strcmp(argv[i], "--moedern-model") == 0 && i + 1 < argc)
            moedern_model_path = argv[++i];
        else if (strcmp(argv[i], "--host") == 0 && i + 1 < argc)
            host = argv[++i];
        else if (strcmp(argv[i], "--systemone-model") == 0 && i + 1 < argc)
            systemone_model_path = argv[++i];
        else if (strcmp(argv[i], "--image-root") == 0 && i + 1 < argc)
            g_image_root = argv[++i];
        else if (strcmp(argv[i], "--model-root") == 0 && i + 1 < argc)
            g_model_root = argv[++i];
        else if (strcmp(argv[i], "--port") == 0 && i + 1 < argc)
            port = atoi(argv[++i]);
        else if (strcmp(argv[i], "-t") == 0 && i + 1 < argc)
            n_threads = atoi(argv[++i]);
        else if (strcmp(argv[i], "--gpu-backend") == 0 && i + 1 < argc)
            crispembed_set_gpu_backend(argv[++i]);
        else if (strcmp(argv[i], "--det") == 0 && i + 1 < argc)
            det_model_path = argv[++i];
        else if (strcmp(argv[i], "--rec") == 0 && i + 1 < argc)
            rec_model_path = argv[++i];
        else if (strcmp(argv[i], "--accept-biometric") == 0)
            accept_biometric = true;
        else if (strcmp(argv[i], "--vit") == 0 && i + 1 < argc)
            vit_model_path = argv[++i];
        else if (strcmp(argv[i], "--pix2struct") == 0 && i + 1 < argc)
            pix2struct_model_path = argv[++i];
        else if (strcmp(argv[i], "--clip-text") == 0 && i + 1 < argc)
            clip_text_model_path = argv[++i];
        else if (strcmp(argv[i], "--ocr") == 0 && i + 1 < argc)
            ocr_model_path = argv[++i];
        else if (strcmp(argv[i], "--marker-model") == 0 && i + 1 < argc) {
            marker_model_path = argv[++i];
            marker_enabled = true;
        } else if (strcmp(argv[i], "--marker-pdfium") == 0 && i + 1 < argc)
            marker_pdfium_path = argv[++i];
        else if (strcmp(argv[i], "--marker-text") == 0) {
            marker_mode = 1;
            marker_enabled = true;
        } else if (strcmp(argv[i], "--marker-force-ocr") == 0) {
            marker_mode = 2;
            marker_enabled = true;
        }
        else if (strcmp(argv[i], "--ocr-det") == 0 && i + 1 < argc)
            ocr_det_model_path = argv[++i];
        else if (strcmp(argv[i], "--ocr-rec") == 0 && i + 1 < argc)
            ocr_rec_model_path = argv[++i];
        else if (strcmp(argv[i], "--layout") == 0 && i + 1 < argc)
            layout_model_path = argv[++i];
        else if (strcmp(argv[i], "--table") == 0 && i + 1 < argc)
            table_model_path = argv[++i];
        else if (strcmp(argv[i], "--formula") == 0 && i + 1 < argc)
            formula_model_path = argv[++i];
        else if (strcmp(argv[i], "--tables") == 0)
            route_tables = true;
        else if (strcmp(argv[i], "--formulas") == 0)
            route_formulas = true;
        else if (strcmp(argv[i], "--text-det") == 0 && i + 1 < argc)
            text_det_model_path = argv[++i];
        else if (strcmp(argv[i], "--ner") == 0 && i + 1 < argc)
            ner_model_path = argv[++i];
        else if (strcmp(argv[i], "--lid") == 0 && i + 1 < argc)
            lid_model_path = argv[++i];
        else if (strcmp(argv[i], "--ocr-max-tokens") == 0 && i + 1 < argc)
            ocr_max_tokens = atoi(argv[++i]);
        else if (strcmp(argv[i], "--offline") == 0)
            crispembed_mgr::set_offline(true);
        else if (strcmp(argv[i], "--dim") == 0 && i + 1 < argc)
            server_dim = atoi(argv[++i]);
        else if (strcmp(argv[i], "--ocr-prompt") == 0 && i + 1 < argc)
            ocr_prompt = argv[++i];
        else if (strcmp(argv[i], "--ocr-pipeline") == 0)
            enable_ocr_orch = true;
        else if (strcmp(argv[i], "--ocr-engine") == 0 && i + 1 < argc)
            ocr_engine_name = argv[++i];
        else if (strcmp(argv[i], "--ocr-cls") == 0 && i + 1 < argc)
            ocr_cls_model_path = argv[++i];
        else if (strcmp(argv[i], "--vlm-model") == 0 && i + 1 < argc)
            vlm_model_path = argv[++i];
        else if (strcmp(argv[i], "--vlm-engine") == 0 && i + 1 < argc)
            vlm_engine = atoi(argv[++i]);
        else if (strcmp(argv[i], "--punct-model") == 0 && i + 1 < argc)
            punct_model_path = argv[++i];
        else if (strcmp(argv[i], "--sr-model") == 0 && i + 1 < argc)
            sr_model_path = argv[++i];
        else if (strcmp(argv[i], "--pan-model") == 0 && i + 1 < argc)
            pan_model_path = argv[++i];
        else if (strcmp(argv[i], "--sam2-model") == 0 && i + 1 < argc)
            sam2_model_path = argv[++i];
        else if (strcmp(argv[i], "--hat-model") == 0 && i + 1 < argc)
            hat_model_path = argv[++i];
        else if (strcmp(argv[i], "--dat-model") == 0 && i + 1 < argc)
            dat_model_path = argv[++i];
        else if (strcmp(argv[i], "--safmn-model") == 0 && i + 1 < argc)
            safmn_model_path = argv[++i];
        else if (strcmp(argv[i], "--esrgan-model") == 0 && i + 1 < argc)
            esrgan_model_path = argv[++i];
        else if (strcmp(argv[i], "--swinir-model") == 0 && i + 1 < argc)
            swinir_model_path = argv[++i];
        else if (strcmp(argv[i], "--tbsrn-model") == 0 && i + 1 < argc)
            tbsrn_model_path = argv[++i];
        else if (strcmp(argv[i], "--restormer-model") == 0 && i + 1 < argc)
            restormer_model_path = argv[++i];
        else if (strcmp(argv[i], "--scunet-model") == 0 && i + 1 < argc)
            scunet_model_path = argv[++i];
        else if (strcmp(argv[i], "--instructir-model") == 0 && i + 1 < argc)
            instructir_model_path = argv[++i];
        else if (strcmp(argv[i], "--adair-model") == 0 && i + 1 < argc)
            adair_model_path = argv[++i];
        else
            // An unrecognised option (or one missing its value) used to be
            // dropped without a word, so a typo'd flag looked like a feature
            // that did not work (issue #56).
            fprintf(stderr, "crispembed-server: warning: ignoring unknown option '%s' (or missing value)\n", argv[i]);
    }

    // ocr_det_model_path counts as a model: `--ocr-pipeline --ocr-det D
    // --ocr-rec R` is a complete standalone configuration (it was rejected
    // with the usage text before, forcing an unrelated -m just to start the
    // OCR endpoint — noticed while smoke-testing the issue-#45 thread fix).
    if (!marker_enabled && systemone_model_path.empty() && model_path.empty() && det_model_path.empty() && vit_model_path.empty() &&
        ocr_model_path.empty() && ocr_det_model_path.empty() && ocr_engine_name.empty() && layout_model_path.empty() &&
        ner_model_path.empty() && sr_model_path.empty() && pan_model_path.empty() && hat_model_path.empty() &&
        dat_model_path.empty() && safmn_model_path.empty() && esrgan_model_path.empty() && swinir_model_path.empty() &&
        moedern_model_path.empty() && tbsrn_model_path.empty() && restormer_model_path.empty() &&
        scunet_model_path.empty() && instructir_model_path.empty() && adair_model_path.empty() &&
        sam2_model_path.empty()) {
        fprintf(stderr, "Usage: crispembed-server -m MODEL [--port 8080] [--host 127.0.0.1]\n");
        fprintf(stderr, "  MODEL can be a .gguf path or a model name (auto-downloads from HuggingFace)\n");
        fprintf(stderr, "  Examples: -m all-MiniLM-L6-v2   -m octen-0.6b   -m model.gguf\n");
        fprintf(stderr, "  --offline never access the network: models must be local paths or already cached\n");
        fprintf(stderr, "            (also CRISPEMBED_OFFLINE=1 or HF_HUB_OFFLINE=1)\n");
        fprintf(stderr, "  --dim N   default Matryoshka truncation of text embeddings (truncate to N dims,\n");
        fprintf(stderr, "            then L2-renormalize). Requests may override it with \"dimensions\"\n");
        fprintf(stderr, "            on /embed, /v1/embeddings, /api/embed and /api/embeddings.\n");
        fprintf(stderr, "\nRequest sandboxing:\n");
        fprintf(stderr, "  --image-root DIR  confine every {\"image\": PATH} request to DIR.\n");
        fprintf(stderr, "                    Endpoints read images by server-side path; without\n");
        fprintf(stderr, "                    this any reachable client can read any file this\n");
        fprintf(stderr, "                    process can. Set it whenever the port is not\n");
        fprintf(stderr, "                    loopback-only.\n");
        fprintf(stderr, "  --model-root DIR  confine client-supplied model paths (e.g. the\n");
        fprintf(stderr, "                    tps-dewarp \"model\" field) to DIR. A GGUF is a graph\n");
        fprintf(stderr, "                    this process executes, so an unconfined model path\n");
        fprintf(stderr, "                    is a code-execution surface, not a data one.\n");
        fprintf(stderr, "\nFace pipeline:\n");
        fprintf(stderr, "  --det MODEL   face detection model (SCRFD GGUF)\n");
        fprintf(stderr, "  --rec MODEL   face recognition model (ArcFace/SFace GGUF)\n");
        fprintf(stderr, "  --accept-biometric  acknowledge biometric processing (see POLICY.md)\n");
        fprintf(stderr, "\nStandalone ViT (SigLIP/CLIP):\n");
        fprintf(stderr, "  --vit MODEL   ViT image embedding model (SigLIP/CLIP GGUF)\n");
        fprintf(stderr, "  --pix2struct MODEL  Pix2Struct document understanding model GGUF\n");
        fprintf(stderr, "  --clip-text MODEL  CLIP text encoder GGUF\n");
        fprintf(stderr, "  --systemone-model MODEL  joint-schema decisions; enables POST /systemone\n");
        fprintf(stderr, "  --moedern-model MODEL  MoEdern raw-text roles; POST /moedern/encode, /moedern/score\n");
        fprintf(stderr, "\nMath OCR (formula recognition):\n");
        fprintf(stderr, "  --ocr MODEL   math OCR model (PP-FormulaNet, HMER, BTTR GGUF)\n");
        fprintf(stderr, "\nLayout detection (document structure):\n");
        fprintf(stderr, "  --layout MODEL   RT-DETRv2 layout detection model GGUF\n");
        fprintf(stderr, "\nText detection:\n");
        fprintf(stderr, "  --text-det MODEL  Surya text line detection model GGUF\n");
        fprintf(stderr, "\nNamed Entity Recognition:\n");
        fprintf(stderr, "  --ner MODEL       GLiNER zero-shot NER model GGUF\n");
        fprintf(stderr, "  --lid MODEL       text LID model GGUF (CLD3 or GlotLID)\n");
        fprintf(stderr, "\nOCR orchestrator (full pipeline with routing + cleanup + accept-gate):\n");
        fprintf(stderr, "  --ocr-pipeline    enable POST /ocr/pipeline endpoint\n");
        fprintf(stderr, "  --ocr-max-tokens N  generation cap for VLM OCR engines (0 = engine default)\n");
        fprintf(stderr, "  --marker-model FILE native Marker-style processing with a local TeleOCR GGUF\n");
        fprintf(stderr, "  --marker-text       model-free PDF text mode; --marker-force-ocr forces recognition\n");
        fprintf(stderr, "  --marker-pdfium LIB explicit native PDFium library for PDF inputs\n");
        fprintf(stderr, "  --ocr-prompt TEXT   default instruction for prompt-following VLM OCR engines\n");
        fprintf(stderr,
                "                      (qwen2vl/qwen3vl/olmocr/teleocr, internvl2, lfm2-vl, granite-vision);\n");
        fprintf(stderr, "                      POST /ocr/model also takes a per-request \"prompt\"\n");
        fprintf(stderr, "  --ocr-det MODEL   detection model (required with --ocr-pipeline unless --ocr-engine)\n");
        fprintf(stderr, "  --ocr-rec MODEL   recognition model (required with --ocr-pipeline unless --ocr-engine)\n");
        fprintf(stderr, "  --ocr-engine NAME explicit pipeline engine (ppocrv6, tesseract, easyocr, got, glm, "
                        "qwen35-ocr, ovisocr2, ovisocr3, ...);\n");
        fprintf(stderr, "                    engine names and model defaults match the CLI's --ocr-engine\n");
        fprintf(stderr, "  --ocr-cls MODEL   optional PP-LCNet 0/180 line-orientation classifier\n");
        fprintf(stderr, "  --table MODEL     Tesseract-LSTM table-cell model (optional)\n");
        fprintf(stderr, "  --formula MODEL   PP-FormulaNet model (optional)\n");
        fprintf(stderr, "  --tables          route layout tables to --table\n");
        fprintf(stderr, "  --formulas        route layout formulas to --formula\n");
        fprintf(stderr, "  --vlm-model MODEL VLM escalation fallback GGUF (optional)\n");
        fprintf(stderr, "  --vlm-engine N    VLM backend: 0=GOT 1=GLM 2=Qwen2-VL 3=InternVL2\n");
        fprintf(stderr, "  --punct-model M   post-OCR punctuation/spacing GGUF (optional)\n");
        fprintf(stderr, "\nText super-resolution (low-DPI upscaling before OCR):\n");
        fprintf(stderr, "  --sr-model MODEL  text SR GGUF (NAFNet+PixelShuffle, 2x or 4x); enables POST /text/sr\n");
        fprintf(stderr, "\nPAN super-resolution (whole-image upscaling):\n");
        fprintf(stderr, "  --pan-model MODEL PAN SR GGUF (Pixel Attention Network, 2x or 4x); enables POST /pan/sr\n");
        fprintf(stderr, "\nSAM 2.1 image segmentation (point/box prompts):\n");
        fprintf(stderr,
                "  --sam2-model MODEL SAM 2.1 GGUF or registry name (sam2.1-hiera-tiny); enables POST /sam2/segment\n");
        fprintf(stderr, "\nHAT super-resolution (Hybrid Attention Transformer, 4x):\n");
        fprintf(stderr, "  --hat-model MODEL   HAT GGUF (21M params, CVPR 2023 SOTA); enables POST /hat/sr\n");
        fprintf(stderr, "\nDAT super-resolution (Dual Aggregation Transformer, 2x):\n");
        fprintf(stderr, "  --dat-model MODEL   DAT-light GGUF (830K params, ICCV 2023); enables POST /dat/sr\n");
        fprintf(stderr, "\nSAFMN super-resolution (4x):\n");
        fprintf(stderr, "  --safmn-model MODEL SAFMN GGUF (228K params, ICCV 2023); enables POST /safmn/sr\n");
        fprintf(stderr, "\nReal-ESRGAN super-resolution (4x):\n");
        fprintf(stderr, "  --esrgan-model MODEL Real-ESRGAN GGUF (620K params); enables POST /esrgan/sr\n");
        fprintf(stderr, "\nSwinIR super-resolution (Swin Transformer, 2x/3x/4x):\n");
        fprintf(stderr,
                "  --swinir-model MODEL SwinIR GGUF (lightweight, ~0.9M-4.2M params); enables POST /swinir/sr\n");
        fprintf(stderr, "\nTBSRN text-line super-resolution:\n");
        fprintf(stderr,
                "  --tbsrn-model MODEL TBSRN GGUF (Telescope, 1.1M params, fixed 4x); enables POST /tbsrn/sr\n");
        fprintf(stderr, "\nRestormer image restoration:\n");
        fprintf(stderr, "  --restormer-model MODEL Restormer GGUF (26M params, CVPR 2022); enables POST /restormer\n");
        fprintf(stderr, "\nSCUNet image denoising:\n");
        fprintf(stderr, "  --scunet-model MODEL  SCUNet GGUF (18M params, CVPR 2022); enables POST /scunet/denoise\n");
        fprintf(stderr, "\nInstructIR all-in-one image restoration:\n");
        fprintf(
            stderr,
            "  --instructir-model MODEL  InstructIR GGUF (16M params, ECCV 2024); enables POST /instructir/restore\n");
        fprintf(stderr, "\nAdaIR all-in-one image restoration:\n");
        fprintf(stderr, "  --adair-model MODEL  AdaIR GGUF (28.8M params, ICLR 2025); enables POST /adair/restore\n");
        return 1;
    }

    // Text embedding model (optional when only face models are loaded)
    crispembed_context * ctx = nullptr;
    const crispembed_hparams * hp = nullptr;
    int dim = 0;
    std::mutex model_mutex;
    std::string model_name;

    if (!model_path.empty()) {
        std::string resolved = crispembed_mgr::resolve_model(model_path, true);
        if (resolved.empty()) {
            fprintf(stderr, "Failed to resolve model '%s'\n", model_path.c_str());
            return 1;
        }
        model_path = resolved;
        ctx = crispembed_init(model_path.c_str(), n_threads);
        if (!ctx) {
            fprintf(stderr, "Failed to load model '%s'\n", model_path.c_str());
            return 1;
        }
        hp = crispembed_get_hparams(ctx);
        dim = hp->n_output > 0 ? hp->n_output : hp->n_embd;
        if (server_dim < 0 || (server_dim > 0 && dim > 0 && server_dim > dim)) {
            fprintf(stderr, "error: --dim %d is outside 1..%d (the model's native dimension)\n", server_dim, dim);
            return 1;
        }
        if (server_dim > 0 && server_dim < dim) {
            crispembed_set_dim(ctx, server_dim);
            fprintf(stderr, "crispembed-server: Matryoshka truncation %d -> %d dims (L2-renormalized)\n", dim,
                    server_dim);
        }
        model_name = model_path;
        auto slash = model_name.find_last_of("/\\");
        if (slash != std::string::npos) model_name = model_name.substr(slash + 1);
        auto dot = model_name.rfind(".gguf");
        if (dot != std::string::npos) model_name = model_name.substr(0, dot);
    }

    // Per-request Matryoshka truncation (issue #55). OpenAI and Ollama both
    // call the field "dimensions". The library truncates and re-normalizes
    // (crispembed_set_dim), so the client receives a unit vector of the
    // requested length instead of truncating — and re-normalizing — itself.
    // Returns 0 when absent, the requested size when valid, -1 when invalid
    // (err is filled). A value equal to the native size is a valid no-op.
    auto request_dim = [&](const std::string & body, std::string & err) -> int {
        if (core_json::json_find_key_value(body, "dimensions") == std::string::npos) return 0;
        const double v = json_extract_number(body, "dimensions", 0.0);
        const int n = (int)v;
        if ((double)n != v || n < 1 || (dim > 0 && n > dim)) {
            err = "dimensions must be an integer in 1.." + std::to_string(dim);
            return -1;
        }
        return n;
    };
    // Applies a request's dimensions for the duration of one locked encode and
    // restores the server default (--dim) afterwards; the context is shared.
    struct dim_scope {
        crispembed_context * c;
        int restore;
        bool active;
        ~dim_scope() {
            if (active) crispembed_set_dim(c, restore);
        }
    };

    std::unique_ptr<crispembed_systemone_context, decltype(&crispembed_systemone_free)> systemone(
        nullptr, crispembed_systemone_free);
    std::mutex systemone_mutex;
    if (!systemone_model_path.empty()) {
        const auto resolved = crispembed_mgr::resolve_model(systemone_model_path, true);
        if (resolved.empty()) {
            fprintf(stderr, "Failed to resolve SystemOne model\n");
            return 1;
        }
        systemone.reset(crispembed_systemone_init(resolved.c_str(), n_threads));
        if (!systemone) {
            fprintf(stderr, "Failed to load SystemOne model: %s\n", crispembed_systemone_error(nullptr));
            return 1;
        }
    }

    std::unique_ptr<crispembed_moedern_context, decltype(&crispembed_moedern_free)> moedern(nullptr,
                                                                                            crispembed_moedern_free);
    std::mutex moedern_mutex;
    if (!moedern_model_path.empty()) {
        const auto resolved = crispembed_mgr::resolve_model(moedern_model_path, true);
        if (resolved.empty()) {
            fprintf(stderr, "Failed to resolve MoEdern model\n");
            return 1;
        }
        moedern.reset(crispembed_moedern_init(resolved.c_str(), n_threads > 2 ? 2 : n_threads));
        if (!moedern) {
            fprintf(stderr, "Failed to load MoEdern model: %s\n", crispembed_moedern_error(nullptr));
            return 1;
        }
    }

    httplib::Server svr;

    // CORS: allow browser access from any origin
    svr.set_default_headers({
        { "Access-Control-Allow-Origin", "*" },
        { "Access-Control-Allow-Methods", "POST, GET, OPTIONS" },
        { "Access-Control-Allow-Headers", "Content-Type, Authorization" },
    });
    svr.Options("/(.*)", [](const httplib::Request &, httplib::Response & res) { res.status = 204; });

    // Raw token features and tied masked-LM predictions.
    // Typed schema decisions: native rendering, encoding and calibration.
    svr.Post("/systemone", [&](const httplib::Request & req, httplib::Response & res) {
        if (!systemone) {
            res.status = 503;
            res.set_content("{\"error\":\"no SystemOne model loaded\"}", "application/json");
            return;
        }
        if (req.body.size() > 65536 || req.body.find('\0') != std::string::npos) {
            res.status = 400;
            res.set_content("{\"error\":\"SystemOne requires NUL-free JSON within64KiB\"}", "application/json");
            return;
        }
        std::lock_guard<std::mutex> lock(systemone_mutex);
        const auto * result = crispembed_systemone_run_json(systemone.get(), req.body.c_str());
        if (!result) {
            res.status = 400;
            res.set_content("{\"error\":\"" + json_escape(crispembed_systemone_error(systemone.get())) + "\"}",
                            "application/json");
            return;
        }
        res.set_content(result, "application/json");
    });

    // MoEdern raw text with explicit roles; separate from pooled /embed and /colbert.
    auto moedern_field = [](const std::string & body, const char * key, std::string & out) {
        const size_t pos = core_json::json_find_key_value(body, key);
        size_t end = 0;
        return pos != std::string::npos && core_json::json_decode_string(body, pos, out, end);
    };
    auto moedern_reject = [&](httplib::Response & res, int status, const std::string & why) {
        res.status = status;
        res.set_content("{\"error\":\"" + json_escape(why) + "\"}", "application/json");
    };
    svr.Post("/moedern/encode", [&](const httplib::Request & req, httplib::Response & res) {
        if (!moedern) return moedern_reject(res, 503, "no MoEdern model loaded");
        std::string text, role;
        if (req.body.size() > 200000 || !moedern_field(req.body, "text", text) ||
            !moedern_field(req.body, "role", role) || (role != "query" && role != "document") ||
            text.find('\0') != std::string::npos)
            return moedern_reject(res, 400, "MoEdern requires {text, role: query|document}");
        std::lock_guard<std::mutex> lock(moedern_mutex);
        const auto * r = crispembed_moedern_encode(moedern.get(), text.c_str(), role == "query" ? 0 : 1);
        if (!r) return moedern_reject(res, 400, crispembed_moedern_error(moedern.get()));
        std::ostringstream js;
        js << std::setprecision(9) << "{\"role\":\"" << role << "\"";
        auto list = [&](const char * key, auto * v, int n, bool real) {
            js << ",\"" << key << "\":[";
            for (int i = 0; i < n; ++i) {
                if (i) js << ",";
                if (real)
                    js << double(v[i]);
                else
                    js << int(v[i]);
            }
            js << "]";
        };
        list("ids", r->ids, r->n_tokens, false);
        list("supplied_mask", r->supplied_mask, r->n_tokens, false);
        list("effective_mask", r->effective_mask, r->n_tokens, false);
        list("scoring_mask", r->scoring_mask, r->n_tokens, false);
        list("expansion_positions", r->expansion_positions, r->expansion_count, false);
        list("all_vectors", r->all_vectors, r->n_tokens * 128, true);
        list("selected_vectors", r->selected_vectors, r->n_selected * 128, true);
        js << "}";
        res.set_content(js.str(), "application/json");
    });
    svr.Post("/moedern/score", [&](const httplib::Request & req, httplib::Response & res) {
        if (!moedern) return moedern_reject(res, 503, "no MoEdern model loaded");
        std::string query, document;
        if (req.body.size() > 200000 || !moedern_field(req.body, "query", query) ||
            !moedern_field(req.body, "document", document) || query.find('\0') != std::string::npos ||
            document.find('\0') != std::string::npos)
            return moedern_reject(res, 400, "MoEdern score requires {query, document}");
        std::lock_guard<std::mutex> lock(moedern_mutex);
        float value = 0;
        if (crispembed_moedern_score(moedern.get(), query.c_str(), document.c_str(), &value) != 1)
            return moedern_reject(res, 400, crispembed_moedern_error(moedern.get()));
        std::ostringstream js;
        js << std::setprecision(9) << "{\"score\":" << double(value) << "}";
        res.set_content(js.str(), "application/json");
    });

    svr.Post("/decide", [&](const httplib::Request & req, httplib::Response & res) {
        if (!ctx) {
            res.status = 503;
            res.set_content("{\"error\":\"no embedding model loaded\"}", "application/json");
            return;
        }
        if (!crispembed_has_decision(ctx)) {
            res.status = 400;
            res.set_content("{\"error\":\"model has no typed-decision head\"}", "application/json");
            return;
        }
        std::lock_guard<std::mutex> lock(model_mutex);
        const char * result = crispembed_decide_json(ctx, req.body.c_str());
        if (!result) {
            res.status = 400;
            res.set_content("{\"error\":\"" + json_escape(crispembed_decision_error(ctx)) + "\"}", "application/json");
            return;
        }
        res.set_content(result, "application/json");
    });

    svr.Post("/tokens", [&](const httplib::Request & req, httplib::Response & res) {
        handle_encoder_request(req, res, ctx, model_mutex, 0);
    });
    svr.Post("/masked-logits", [&](const httplib::Request & req, httplib::Response & res) {
        handle_encoder_request(req, res, ctx, model_mutex, 1);
    });
    svr.Post("/fill-mask", [&](const httplib::Request & req, httplib::Response & res) {
        handle_encoder_request(req, res, ctx, model_mutex, 2);
    });

    // POST /embed — simple API
    svr.Post("/embed", [&](const httplib::Request & req, httplib::Response & res) {
        if (!ctx) {
            res.status = 503;
            res.set_content("{\"error\": \"no text model loaded\"}", "application/json");
            return;
        }
        std::vector<std::string> texts;
        auto body = req.body;

        // "texts" array, else "text" string (JSON-escaping aware)
        if (json_extract_strings(body, "texts", texts) == 0) {
            json_extract_strings(body, "text", texts);
        }

        if (texts.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"no texts provided\"}", "application/json");
            return;
        }
        std::string dim_err;
        const int req_dim = request_dim(body, dim_err);
        if (req_dim < 0) {
            res.status = 400;
            res.set_content("{\"error\": \"" + json_escape(dim_err) + "\"}", "application/json");
            return;
        }

        std::lock_guard<std::mutex> lock(model_mutex);
        dim_scope dscope{ ctx, server_dim, req_dim > 0 };
        if (req_dim > 0) crispembed_set_dim(ctx, req_dim);
        auto t0 = std::chrono::steady_clock::now();

        std::ostringstream js;
        js << "{\"embeddings\": [";
        int out_dim = 0; // actual (possibly truncated) length

        if (texts.size() == 1) {
            // Single text: use single encode
            int d = 0;
            const float * vec = crispembed_encode(ctx, texts[0].c_str(), &d);
            if (!vec || d <= 0) {
                res.status = 500;
                res.set_content("{\"error\": \"encoding failed\"}", "application/json");
                return;
            }
            out_dim = d;
            js << "[";
            for (int j = 0; j < d; j++) {
                if (j > 0) js << ", ";
                js << vec[j];
            }
            js << "]";
        } else {
            // Multiple texts: use batched encode (single graph on GPU)
            std::vector<const char *> ptrs(texts.size());
            for (size_t i = 0; i < texts.size(); i++) ptrs[i] = texts[i].c_str();
            int d = 0;
            const float * vecs = crispembed_encode_batch(ctx, ptrs.data(), (int)texts.size(), &d);
            if (!vecs || d <= 0) {
                res.status = 500;
                res.set_content("{\"error\": \"batch encoding failed\"}", "application/json");
                return;
            }
            out_dim = d;
            for (size_t i = 0; i < texts.size(); i++) {
                if (i > 0) js << ", ";
                js << "[";
                for (int j = 0; j < d; j++) {
                    if (j > 0) js << ", ";
                    js << vecs[i * d + j];
                }
                js << "]";
            }
        }

        // Report the length actually returned: with --dim / "dimensions" it is
        // the truncated size, not the model's native one.
        js << "], \"dim\": " << out_dim << "}";

        auto t1 = std::chrono::steady_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();
        fprintf(stderr, "crispembed-server: encoded %zu text(s) in %.1f ms\n", texts.size(), ms);

        res.set_content(js.str(), "application/json");
    });

    // POST /v1/embeddings — OpenAI-compatible
    svr.Post("/v1/embeddings", [&](const httplib::Request & req, httplib::Response & res) {
        if (!ctx) {
            res.status = 503;
            res.set_content("{\"error\": \"no text model loaded\"}", "application/json");
            return;
        }
        std::vector<std::string> texts;
        auto body = req.body;
        json_extract_strings(body, "input", texts);

        if (texts.empty()) {
            res.status = 400;
            res.set_content("{\"error\": {\"message\": \"no input\"}}", "application/json");
            return;
        }
        std::string dim_err;
        const int req_dim = request_dim(body, dim_err);
        if (req_dim < 0) {
            res.status = 400;
            res.set_content("{\"error\": {\"message\": \"" + json_escape(dim_err) +
                                "\", \"type\": \"invalid_request_error\", \"param\": \"dimensions\"}}",
                            "application/json");
            return;
        }

        std::lock_guard<std::mutex> lock(model_mutex);
        dim_scope dscope{ ctx, server_dim, req_dim > 0 };
        if (req_dim > 0) crispembed_set_dim(ctx, req_dim);

        std::ostringstream js;
        // Batch encode all texts at once
        std::vector<const char *> ptrs(texts.size());
        for (size_t i = 0; i < texts.size(); i++) ptrs[i] = texts[i].c_str();
        int d = 0;
        const float * vecs = crispembed_encode_batch(ctx, ptrs.data(), (int)texts.size(), &d);
        if (!vecs || d <= 0) {
            res.status = 500;
            res.set_content("{\"error\": {\"message\": \"encoding failed\"}}", "application/json");
            return;
        }

        js << "{\"object\": \"list\", \"data\": [";
        for (size_t i = 0; i < texts.size(); i++) {
            if (i > 0) js << ", ";
            js << "{\"object\": \"embedding\", \"index\": " << i << ", \"embedding\": [";
            for (int j = 0; j < d; j++) {
                if (j > 0) js << ", ";
                js << vecs[i * d + j];
            }
            js << "]}";
        }
        js << "], \"model\": \"" << json_escape(model_name)
           << "\", \"usage\": {\"prompt_tokens\": 0, \"total_tokens\": 0}}";
        res.set_content(js.str(), "application/json");
    });

    // POST /api/embed — Ollama-compatible (batch)
    // Request:  {"model": "...", "input": ["text1", "text2"]} or {"model": "...", "input": "text"}
    // Response: {"model": "...", "embeddings": [[...], [...]], "total_duration": ns, "load_duration": 0, "prompt_eval_count": n}
    svr.Post("/api/embed", [&](const httplib::Request & req, httplib::Response & res) {
        if (!ctx) {
            res.status = 503;
            res.set_content("{\"error\": \"no text model loaded\"}", "application/json");
            return;
        }
        std::vector<std::string> texts;
        auto body = req.body;

        // Parse "input" — can be array or string (JSON-escaping aware)
        json_extract_strings(body, "input", texts);

        if (texts.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"no input provided\"}", "application/json");
            return;
        }
        std::string dim_err;
        const int req_dim = request_dim(body, dim_err);
        if (req_dim < 0) {
            res.status = 400;
            res.set_content("{\"error\": \"" + json_escape(dim_err) + "\"}", "application/json");
            return;
        }

        std::lock_guard<std::mutex> lock(model_mutex);
        dim_scope dscope{ ctx, server_dim, req_dim > 0 };
        if (req_dim > 0) crispembed_set_dim(ctx, req_dim);
        auto t0 = std::chrono::steady_clock::now();

        std::vector<const char *> ptrs(texts.size());
        for (size_t i = 0; i < texts.size(); i++) ptrs[i] = texts[i].c_str();
        int d = 0;
        const float * vecs = crispembed_encode_batch(ctx, ptrs.data(), (int)texts.size(), &d);
        if (!vecs || d <= 0) {
            res.status = 500;
            res.set_content("{\"error\": \"encoding failed\"}", "application/json");
            return;
        }

        auto t1 = std::chrono::steady_clock::now();
        int64_t total_ns = std::chrono::duration_cast<std::chrono::nanoseconds>(t1 - t0).count();

        std::ostringstream js;
        js << "{\"model\": \"" << json_escape(model_name) << "\", \"embeddings\": [";
        for (size_t i = 0; i < texts.size(); i++) {
            if (i > 0) js << ", ";
            js << "[";
            for (int j = 0; j < d; j++) {
                if (j > 0) js << ", ";
                js << vecs[i * d + j];
            }
            js << "]";
        }
        js << "], \"total_duration\": " << total_ns << ", \"load_duration\": 0"
           << ", \"prompt_eval_count\": " << texts.size() << "}";

        fprintf(stderr, "crispembed-server: /api/embed %zu text(s) in %.1f ms\n", texts.size(), total_ns / 1e6);
        res.set_content(js.str(), "application/json");
    });

    // POST /api/embeddings — Ollama-compatible (single text, legacy)
    // Request:  {"model": "...", "prompt": "text"}
    // Response: {"embedding": [...]}
    svr.Post("/api/embeddings", [&](const httplib::Request & req, httplib::Response & res) {
        if (!ctx) {
            res.status = 503;
            res.set_content("{\"error\": \"no text model loaded\"}", "application/json");
            return;
        }
        std::string text;
        auto body = req.body;

        std::vector<std::string> prompt;
        json_extract_strings(body, "prompt", prompt);
        if (!prompt.empty()) text = prompt.front();

        if (text.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"no prompt provided\"}", "application/json");
            return;
        }
        std::string dim_err;
        const int req_dim = request_dim(body, dim_err);
        if (req_dim < 0) {
            res.status = 400;
            res.set_content("{\"error\": \"" + json_escape(dim_err) + "\"}", "application/json");
            return;
        }

        std::lock_guard<std::mutex> lock(model_mutex);
        dim_scope dscope{ ctx, server_dim, req_dim > 0 };
        if (req_dim > 0) crispembed_set_dim(ctx, req_dim);

        int d = 0;
        const float * vec = crispembed_encode(ctx, text.c_str(), &d);
        if (!vec || d <= 0) {
            res.status = 500;
            res.set_content("{\"error\": \"encoding failed\"}", "application/json");
            return;
        }

        std::ostringstream js;
        js << "{\"embedding\": [";
        for (int j = 0; j < d; j++) {
            if (j > 0) js << ", ";
            js << vec[j];
        }
        js << "]}";

        res.set_content(js.str(), "application/json");
    });

    // ── Face pipeline endpoints ───────────────────────────────────────
    crispembed_face_context * face_det = nullptr;
    crispembed_face_context * face_rec = nullptr;
    std::mutex face_mutex;

    if (!det_model_path.empty()) {
        face_det = crispembed_face_init(det_model_path.c_str(), n_threads);
        if (!face_det) fprintf(stderr, "Warning: failed to load detection model '%s'\n", det_model_path.c_str());
    }
    if (!rec_model_path.empty()) {
        // Fail closed: serving /face over HTTP exposes biometric templates to every
        // client that can reach the port, so require acknowledgement before the
        // model is loaded at all.
        if (!crispembed_mgr::accept_biometric_use(rec_model_path.c_str(), accept_biometric)) {
            return 1;
        }
        face_rec = crispembed_face_init(rec_model_path.c_str(), n_threads);
        if (!face_rec) fprintf(stderr, "Warning: failed to load recognition model '%s'\n", rec_model_path.c_str());

        // The acknowledgement above is made once, by whoever starts the process.
        // Every HTTP client that can reach the port then inherits it, and there
        // is no authentication anywhere in this server. Bound to loopback that
        // is a local tool; bound to a routable address it is an open biometric
        // endpoint, and one that reads its input by server-side path. Warn
        // rather than refuse: containers legitimately bind 0.0.0.0 behind a
        // proxy that does the authenticating.
        const bool loopback = host == "127.0.0.1" || host == "localhost" || host == "::1";
        if (face_rec && !loopback) {
            fprintf(stderr,
                    "\n"
                    "WARNING: /face is bound to %s, not loopback, and this server has no\n"
                    "         authentication. Anyone who can reach %s:%d can extract face\n"
                    "         templates — GDPR Art. 9 special-category data — from any image\n"
                    "         file readable by this process, since /face takes a server-side\n"
                    "         path. Put an authenticating proxy in front of it, or bind\n"
                    "         127.0.0.1. See POLICY.md §4.\n"
                    "%s\n",
                    host.c_str(), host.c_str(), port,
                    g_image_root.empty() ? "         --image-root is NOT set, so that is every readable file on\n"
                                           "         this host. Set it to the one directory images may come from.\n"
                                         : "");
        }
    }

    // POST /detect — face detection
    // Request:  {"image": "/path/to/image.jpg", "conf": 0.5}
    // Response: {"faces": [{"bbox":[x,y,w,h], "conf":0.9, "landmarks":[...]}]}
    svr.Post("/detect", [&](const httplib::Request & req, httplib::Response & res) {
        if (!face_det) {
            res.status = 503;
            res.set_content("{\"error\": \"no detection model loaded (use --det)\"}", "application/json");
            return;
        }

        auto body = req.body;
        std::string image_path;
        float conf = 0.5f;
        int det_size = 0;

        image_path = extract_image_path(body);
        conf = (float)json_extract_number(body, "conf", conf);
        det_size = (int)json_extract_number(body, "det_size", det_size);

        if (image_path.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"no image path\"}", "application/json");
            return;
        }

        std::lock_guard<std::mutex> lock(face_mutex);
        int n = 0;
        auto * dets = crispembed_detect_faces(face_det, image_path.c_str(), conf, det_size, &n);

        std::ostringstream js;
        js << "{\"faces\": [";
        for (int i = 0; i < n; i++) {
            if (i > 0) js << ", ";
            js << "{\"bbox\":[" << dets[i].x << "," << dets[i].y << "," << dets[i].w << "," << dets[i].h
               << "], \"conf\":" << dets[i].confidence << ", \"landmarks\":[";
            for (int k = 0; k < 10; k++) {
                if (k > 0) js << ",";
                js << dets[i].landmarks[k];
            }
            js << "]}";
        }
        js << "]}";
        res.set_content(js.str(), "application/json");
    });

    // POST /face — full pipeline: detect + align + encode
    // Request:  {"image": "/path/to/image.jpg", "conf": 0.5}
    // Response: {"faces": [{"bbox":[...], "conf":..., "landmarks":[...], "embedding":[...]}]}
    svr.Post("/face", [&](const httplib::Request & req, httplib::Response & res) {
        if (!face_det || !face_rec) {
            res.status = 503;
            res.set_content("{\"error\": \"need both --det and --rec models\"}", "application/json");
            return;
        }

        auto body = req.body;
        std::string image_path;
        float conf = 0.5f;
        int det_size = 0;

        image_path = extract_image_path(body);
        conf = (float)json_extract_number(body, "conf", conf);
        det_size = (int)json_extract_number(body, "det_size", det_size);

        if (image_path.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"no image path\"}", "application/json");
            return;
        }

        std::lock_guard<std::mutex> lock(face_mutex);
        auto t0 = std::chrono::steady_clock::now();
        int n = 0;
        auto * results = crispembed_face_pipeline(face_det, face_rec, image_path.c_str(), conf, det_size, &n);
        auto t1 = std::chrono::steady_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        std::ostringstream js;
        js << "{\"faces\": [";
        for (int i = 0; i < n; i++) {
            if (i > 0) js << ", ";
            js << "{\"bbox\":[" << results[i].det.x << "," << results[i].det.y << "," << results[i].det.w << ","
               << results[i].det.h << "], \"conf\":" << results[i].det.confidence << ", \"landmarks\":[";
            for (int k = 0; k < 10; k++) {
                if (k > 0) js << ",";
                js << results[i].det.landmarks[k];
            }
            js << "], \"embedding\":[";
            for (int j = 0; j < results[i].embedding_dim; j++) {
                if (j > 0) js << ",";
                js << results[i].embedding[j];
            }
            js << "]}";
        }
        js << "], \"duration_ms\": " << ms << "}";

        fprintf(stderr, "crispembed-server: /face %d faces in %.1f ms\n", n, ms);
        res.set_content(js.str(), "application/json");
    });

    // ── Standalone ViT (SigLIP/CLIP) endpoints ─────────────────────────
    crispembed_vit_context * vit_ctx = nullptr;
    std::mutex vit_mutex;

    if (!vit_model_path.empty()) {
        vit_ctx = crispembed_vit_init(vit_model_path.c_str(), n_threads);
        if (!vit_ctx) fprintf(stderr, "Warning: failed to load ViT model '%s'\n", vit_model_path.c_str());
    }

    // POST /vit/encode — standalone ViT image embedding
    // Request:  {"image": "/path/to/image.jpg"}
    // Response: {"embedding": [...], "dim": N}
    svr.Post("/vit/encode", [&](const httplib::Request & req, httplib::Response & res) {
        if (!vit_ctx) {
            res.status = 503;
            res.set_content("{\"error\": \"no ViT model loaded (use --vit)\"}", "application/json");
            return;
        }

        auto body = req.body;
        std::string image_path;

        image_path = extract_image_path(body);

        if (image_path.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"no image path\"}", "application/json");
            return;
        }

        std::lock_guard<std::mutex> lock(vit_mutex);
        auto t0 = std::chrono::steady_clock::now();

        int d = 0;
        const float * vec = crispembed_vit_encode_file(vit_ctx, image_path.c_str(), &d);
        if (!vec || d <= 0) {
            res.status = 500;
            res.set_content("{\"error\": \"ViT encoding failed\"}", "application/json");
            return;
        }

        auto t1 = std::chrono::steady_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        std::ostringstream js;
        js << "{\"embedding\": [";
        for (int j = 0; j < d; j++) {
            if (j > 0) js << ", ";
            js << vec[j];
        }
        js << "], \"dim\": " << d << "}";

        fprintf(stderr, "crispembed-server: /vit/encode in %.1f ms (dim=%d)\n", ms, d);
        res.set_content(js.str(), "application/json");
    });

    // ── Pix2Struct (document understanding) ──
    crispembed_pix2struct_context * pix2struct_ctx = nullptr;
    std::mutex pix2struct_mutex;

    if (!pix2struct_model_path.empty()) {
        pix2struct_ctx = crispembed_pix2struct_init(pix2struct_model_path.c_str(), n_threads);
        if (!pix2struct_ctx)
            fprintf(stderr, "Warning: failed to load Pix2Struct model '%s'\n", pix2struct_model_path.c_str());
    }

    // POST /pix2struct/generate — document understanding image-to-text
    // Request:  {"image": "/path/to/doc.png", "max_tokens": 256}
    // Response: {"text": "...", "ms": M}
    svr.Post("/pix2struct/generate", [&](const httplib::Request & req, httplib::Response & res) {
        if (!pix2struct_ctx) {
            res.status = 503;
            res.set_content("{\"error\": \"no Pix2Struct model loaded (use --pix2struct)\"}", "application/json");
            return;
        }

        auto body = req.body;
        std::string image_path;
        int max_tokens = 256;

        image_path = extract_image_path(body);
        max_tokens = (int)json_extract_number(body, "max_tokens", max_tokens);

        if (image_path.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"no image path\"}", "application/json");
            return;
        }

        int w, h, ch;
        unsigned char * data = stbi_load(image_path.c_str(), &w, &h, &ch, 0);
        if (!data) {
            res.status = 400;
            res.set_content("{\"error\": \"cannot load image\"}", "application/json");
            return;
        }

        std::lock_guard<std::mutex> lock(pix2struct_mutex);
        auto t0 = std::chrono::steady_clock::now();

        const char * text = crispembed_pix2struct_generate(pix2struct_ctx, data, w, h, max_tokens);
        stbi_image_free(data);

        if (!text) {
            res.status = 500;
            res.set_content("{\"error\": \"Pix2Struct generation failed\"}", "application/json");
            return;
        }

        auto t1 = std::chrono::steady_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        std::ostringstream js;
        js << "{\"text\": \"" << json_escape(text) << "\", \"ms\": " << std::fixed << std::setprecision(1) << ms << "}";

        fprintf(stderr, "crispembed-server: /pix2struct/generate in %.1f ms\n", ms);
        crispembed_pix2struct_free_text(text);
        res.set_content(js.str(), "application/json");
    });

    // ── CLIP text encoder ──
    crispembed_clip_text_context * clip_text_ctx = nullptr;
    std::mutex clip_text_mutex;

    if (!clip_text_model_path.empty()) {
        clip_text_ctx = crispembed_clip_text_init(clip_text_model_path.c_str(), n_threads);
        if (!clip_text_ctx)
            fprintf(stderr, "Warning: failed to load CLIP text model '%s'\n", clip_text_model_path.c_str());
    }

    // ── Math OCR ──
    void * ocr_model_ctx = nullptr;
    std::mutex ocr_model_mutex;
    crispembed_marker_context * marker_ctx = nullptr;
    std::mutex marker_mutex;
    if (marker_enabled) {
        auto config = crispembed_marker_default_config();
        config.model_path = marker_model_path.c_str();
        config.pdfium_path = marker_pdfium_path.c_str();
        config.mode = marker_mode;
        if (n_threads != 0) config.n_threads = n_threads;
        if (ocr_max_tokens > 0) config.max_tokens = ocr_max_tokens;
        marker_ctx = crispembed_marker_init(&config);
        if (!marker_ctx) {
            fprintf(stderr, "Marker initialization failed: %s\n", crispembed_marker_error(nullptr));
            return 1;
        }
    }

    if (!ocr_model_path.empty()) {
        std::string resolved = crispembed_mgr::resolve_model(ocr_model_path, true);
        if (!resolved.empty()) ocr_model_path = resolved;
        ocr_model_ctx = crispembed_ocr_model_init(ocr_model_path.c_str(), n_threads);
        if (!ocr_model_ctx) fprintf(stderr, "Warning: failed to load math OCR model '%s'\n", ocr_model_path.c_str());
        if (ocr_model_ctx && ocr_max_tokens > 0) crispembed_ocr_model_set_max_tokens(ocr_model_ctx, ocr_max_tokens);
        if (ocr_model_ctx && !ocr_prompt.empty() && !crispembed_ocr_model_set_prompt(ocr_model_ctx, ocr_prompt.c_str()))
            fprintf(stderr, "Warning: --ocr-prompt ignored: OCR model '%s' runs a fixed task prompt\n",
                    ocr_model_path.c_str());
    }

    // ── General OCR Pipeline (text detection + recognition) ──
    void * ocr_pipeline_ctx = nullptr;
    std::mutex ocr_pipeline_mutex;

    // ── OCR Orchestrator (source-type routing + cleanup + accept-gate) ──
    void * ocr_orch_ctx = nullptr;
    std::mutex ocr_orch_mutex;

    if (enable_ocr_orch && !ocr_engine_name.empty()) {
        // Explicit primary engine → single-stage pipeline via the stages
        // builder, mirroring the CLI's --ocr-engine lane (issue #45 follow-up:
        // the flat params path below hard-codes the DBNet det loader, so e.g.
        // a ppocrv6 det GGUF failed with "missing stem conv" and the ppocrv6
        // pipeline was unreachable from the server). Engine ids and per-engine
        // model defaults are the CLI's (examples/cli/main.cpp eng_id) — keep
        // the two maps in sync.
        auto eng_id = [](const std::string & n) -> int {
            if (n == "surya") return 1;
            if (n == "got") return 2;
            if (n == "glm") return 3;
            if (n == "qwen2vl") return 4;
            if (n == "internvl2") return 5;
            if (n == "tesseract") return 6;
            if (n == "parseq") return 7;
            if (n == "deepseek-ocr2" || n == "deepseek_ocr2") return 8;
            if (n == "pix2struct") return 9;
            if (n == "granite-vision" || n == "granite_vision") return 10;
            if (n == "lightonocr") return 11;
            if (n == "qwen35-ocr" || n == "qwen35_ocr") return 20;
            if (n == "ovisocr2") return 21;
            if (n == "ovisocr3") return 22;
            if (n == "qwen3vl") return 12;
            if (n == "unlimited_ocr") return 13;
            if (n == "unified") return 14;
            if (n == "tesseract-fraktur" || n == "tesseract_fraktur") return 15;
            if (n == "ppocrv6") return 16;
            if (n == "easyocr") return 17;
            if (n == "olmocr") return 18;
            if (n == "minicpm-ocr" || n == "minicpm_ocr") return 23;
            if (n == "teleocr") return 24;
            return 0; // dbnet_trocr
        };
        const int eid = eng_id(ocr_engine_name);
        const bool is_vlm = (eid >= 2 && eid <= 5) || (eid >= 8 && eid <= 13) || eid == 14 || eid == 18 || eid == 20 ||
                            eid == 21 || eid == 22 || eid == 23 || eid == 24;
        if ((eid == 14 || eid == 15 || eid == 20 || eid == 21 || eid == 22 || eid == 24) &&
            ocr_rec_model_path.empty()) {
            fprintf(stderr, "error: --ocr-engine %s needs the model via --ocr-rec FILE\n", ocr_engine_name.c_str());
            return 1;
        }
        if (eid == 24) {
            if (!core_env::on("CRISPEMBED_TELEOCR")) {
                fprintf(stderr, "error: teleocr needs CRISPEMBED_TELEOCR=1\n");
                return 1;
            }
            auto * meta = core_gguf::open_metadata(ocr_rec_model_path.c_str());
            const bool profile = meta && core_gguf::kv_str(meta, "general.architecture", "") == "teleocr" &&
                                 core_gguf::kv_u32(meta, "teleocr.gguf_version", 0) == 1;
            if (meta) core_gguf::free_metadata(meta);
            if (!profile) {
                fprintf(stderr, "error: teleocr requires a local TeleOCR version 1 GGUF\n");
                return 1;
            }
        }
        // Experimental MiniCPM-OCR-1.0 reuses the qwen35 decoder kernels, so both gates are required.
        if (eid == 23 && (!core_env::on("CRISPEMBED_MINICPM_OCR") || !core_env::on("CRISPEMBED_QWEN35_OCR"))) {
            fprintf(stderr, "error: experimental minicpm-ocr needs CRISPEMBED_MINICPM_OCR=1 and CRISPEMBED_QWEN35_OCR=1\n");
            return 1;
        }
        if (eid == 22 &&
            (!ocr_prompt.empty() || !core_env::on("CRISPEMBED_QWEN35_OCR") ||
             !core_env::on("CRISPEMBED_OVISOCR3_FRONTEND") || !core_env::on("CRISPEMBED_OVISOCR3_INFERENCE"))) {
            fprintf(stderr, "error: ovisocr3 requires an empty custom prompt and all three experimental gates\n");
            return 1;
        }
        if (eid == 21 &&
            (!ocr_prompt.empty() || !core_env::on("CRISPEMBED_QWEN35_OCR") ||
             !core_env::on("CRISPEMBED_OVISOCR2_FRONTEND") || !core_env::on("CRISPEMBED_OVISOCR2_INFERENCE"))) {
            fprintf(stderr, "error: ovisocr2 requires an empty custom prompt and all three experimental gates\n");
            return 1;
        }
        // Resolve the qualified Ovis alias before checking its exact profile.
        if (eid == 21 || eid == 22) {
            ocr_rec_model_path = crispembed_mgr::resolve_model(ocr_rec_model_path, true);
            if (ocr_rec_model_path.empty()) return 1;
        }
        if (eid == 20 || eid == 21 || eid == 22) {
            auto * meta = core_gguf::open_metadata(ocr_rec_model_path.c_str());
            const bool profile = meta && ((eid == 20 && core_gguf::kv_u32(meta, "qwen35_ocr.format_version", 0) == 1) ||
                                          (eid == 21 && core_gguf::kv_u32(meta, "qwen35_ocr.format_version", 0) == 2 &&
                                           core_gguf::kv_str(meta, "qwen35_ocr.profile", "") == "ovisocr2") ||
                                          (eid == 22 && core_gguf::kv_u32(meta, "qwen35_ocr.format_version", 0) == 3 &&
                                           core_gguf::kv_str(meta, "qwen35_ocr.profile", "") == "ovisocr3"));
            if (meta) core_gguf::free_metadata(meta);
            if (!profile) {
                fprintf(stderr, "error: qwen35/ovis selector requires its exact model profile\n");
                return 1;
            }
        }
        auto resolve = [](const std::string & name) {
            std::string r = crispembed_mgr::resolve_model(name, true);
            return r.empty() ? name : r;
        };
        // Keep model strings alive until the init call returns (it copies them).
        std::string ma, mb, mc;
        if (is_vlm) {
            const char * dflt = (eid == 2)    ? "got-ocr2"
                                : (eid == 3)  ? "glm-ocr"
                                : (eid == 5)  ? "internvl2-ocr"
                                : (eid == 8)  ? "deepseek-ocr2"
                                : (eid == 9)  ? "pix2struct-base"
                                : (eid == 10) ? "granite-vision"
                                : (eid == 11) ? "lightonocr"
                                : (eid == 12) ? "qwen3vl-2b"
                                : (eid == 13) ? "unlimited-ocr"
                                : (eid == 18) ? "olmocr-2-7b"
                                : (eid == 23) ? "minicpm-ocr"
                                              : "qwen2vl-ocr";
            ma = resolve(!ocr_rec_model_path.empty() ? ocr_rec_model_path : dflt);
        } else {
            // PP-OCRv6 pairs its own detector with its own CTC recognizer
            // (same reasoning as the CLI: a DBNet fallback would silently
            // serve a different pipeline under the ppocrv6 name).
            const char * ddflt = (eid == 16) ? "ppocrv6-small-det" : "dbnet-det";
            ma = resolve(ocr_det_model_path.empty() ? ddflt : ocr_det_model_path);
            const char * rdflt = (eid == 6)    ? "tesseract-eng"
                                 : (eid == 7)  ? "parseq"
                                 : (eid == 16) ? "ppocrv6-small-rec"
                                 : (eid == 17) ? "easyocr-english-g2"
                                               : "qwen2vl-ocr";
            mb = resolve(ocr_rec_model_path.empty() ? rdflt : ocr_rec_model_path);
            if (!ocr_cls_model_path.empty()) mc = resolve(ocr_cls_model_path);
            // Unlike the CLI, do NOT declare CRISPEMBED_PPOCRV6_ONESHOT: a
            // warm server amortises the recognizer's Metal init across
            // requests, which is exactly the case the one-shot heuristic
            // exists to avoid (see the CLI's T5 note).
        }
        crispembed_ocr_stage st;
        std::memset(&st, 0, sizeof(st));
        st.source_type = 0; // auto
        st.engine = eid;
        st.model_a = ma.c_str();
        st.model_b = mb.empty() ? nullptr : mb.c_str();
        st.model_c = mc.empty() ? nullptr : mc.c_str();
        // VLM engines ingest the original image and do their own resize;
        // scan-cleanup only for the detection+recognition path (CLI parity).
        st.cleanup_enabled = is_vlm ? 0 : 1;
        st.denoise = 0;
        st.cleanup = crispembed_scan_cleanup_defaults();
        st.det_prob_threshold = 0.3f;
        st.det_box_threshold = 0.5f;
        st.det_target_short = 736;
        // --ocr-max-tokens. Set at startup rather than per request because the
        // orchestrator stage is built once here; /math/ocr takes a per-request
        // "max_tokens" instead. This was hardcoded to 0 until 2026-08-25, the
        // same defect the CLI's stage builder had.
        st.vlm_max_tokens = ocr_max_tokens;
        st.vlm_prompt = ocr_prompt.empty() ? nullptr : ocr_prompt.c_str();
        st.page_segmentation = 0;
        st.min_chars = 8;
        st.min_confidence = 0.5f;
        if (!punct_model_path.empty()) {
            std::string punct_r = crispembed_mgr::resolve_model(punct_model_path, true);
            if (!punct_r.empty()) punct_model_path = punct_r;
        }
        if (!lid_model_path.empty()) {
            std::string lid_r = crispembed_mgr::resolve_model(lid_model_path, true);
            if (!lid_r.empty()) lid_model_path = lid_r;
        }
        ocr_orch_ctx = crispembed_ocr_pipeline_init_stages(
            /*router=*/0, /*nafnet_model=*/nullptr, sr_model_path.empty() ? nullptr : sr_model_path.c_str(),
            punct_model_path.empty() ? nullptr : punct_model_path.c_str(),
            lid_model_path.empty() ? nullptr : lid_model_path.c_str(), /*truecase_model=*/nullptr,
            /*tess_model_dir=*/nullptr, &st, 1, n_threads);
        if (!ocr_orch_ctx)
            fprintf(stderr, "Warning: failed to init OCR orchestrator (engine=%s)\n", ocr_engine_name.c_str());
    } else if (enable_ocr_orch && !ocr_det_model_path.empty()) {
        crispembed_ocr_pipeline_params pp = crispembed_ocr_pipeline_defaults();
        std::string det_r = crispembed_mgr::resolve_model(ocr_det_model_path, true);
        if (!det_r.empty()) ocr_det_model_path = det_r;
        std::string rec_r = crispembed_mgr::resolve_model(ocr_rec_model_path, true);
        if (!rec_r.empty()) ocr_rec_model_path = rec_r;
        pp.det_model = ocr_det_model_path.c_str();
        pp.rec_model = ocr_rec_model_path.c_str();
        if (!vlm_model_path.empty()) {
            std::string vlm_r = crispembed_mgr::resolve_model(vlm_model_path, true);
            if (!vlm_r.empty()) vlm_model_path = vlm_r;
            pp.vlm_model = vlm_model_path.c_str();
            pp.vlm_engine = vlm_engine;
        }
        if (!punct_model_path.empty()) {
            std::string punct_r = crispembed_mgr::resolve_model(punct_model_path, true);
            if (!punct_r.empty()) punct_model_path = punct_r;
            pp.punct_model = punct_model_path.c_str();
        }
        if (!sr_model_path.empty()) {
            pp.sr_model = sr_model_path.c_str();
        }
        if (!layout_model_path.empty()) {
            std::string layout_r = crispembed_mgr::resolve_model(layout_model_path, true);
            if (!layout_r.empty()) layout_model_path = layout_r;
            pp.layout_model = layout_model_path.c_str();
        }
        if (!table_model_path.empty()) {
            std::string table_r = crispembed_mgr::resolve_model(table_model_path, true);
            if (!table_r.empty()) table_model_path = table_r;
            pp.table_model = table_model_path.c_str();
        }
        if (!formula_model_path.empty()) {
            std::string formula_r = crispembed_mgr::resolve_model(formula_model_path, true);
            if (!formula_r.empty()) formula_model_path = formula_r;
            pp.formula_model = formula_model_path.c_str();
        }
        pp.route_tables = route_tables ? 1 : 0;
        pp.route_formulas = route_formulas ? 1 : 0;
        ocr_orch_ctx = crispembed_ocr_pipeline_init(&pp, n_threads);
        if (!ocr_orch_ctx) fprintf(stderr, "Warning: failed to init OCR orchestrator\n");
    }

    if (!ocr_det_model_path.empty() && !ocr_rec_model_path.empty()) {
        std::string det_resolved = crispembed_mgr::resolve_model(ocr_det_model_path, true);
        if (!det_resolved.empty()) ocr_det_model_path = det_resolved;
        std::string rec_resolved = crispembed_mgr::resolve_model(ocr_rec_model_path, true);
        if (!rec_resolved.empty()) ocr_rec_model_path = rec_resolved;
        ocr_pipeline_ctx = crispembed_ocr_init(ocr_det_model_path.c_str(), ocr_rec_model_path.c_str(), n_threads);
        if (!ocr_pipeline_ctx) fprintf(stderr, "Warning: failed to load OCR pipeline models\n");
    }

    // ── Layout Detection ──
    void * layout_ctx = nullptr;
    std::mutex layout_mutex;

    if (!layout_model_path.empty()) {
        std::string resolved = crispembed_mgr::resolve_model(layout_model_path, true);
        if (!resolved.empty()) layout_model_path = resolved;
        layout_ctx = crispembed_layout_init(layout_model_path.c_str(), n_threads);
        if (!layout_ctx) fprintf(stderr, "Warning: failed to load layout model '%s'\n", layout_model_path.c_str());
    }

    // Surya text detection
    void * text_det_ctx = nullptr;
    std::mutex text_det_mutex;

    if (!text_det_model_path.empty()) {
        std::string resolved = crispembed_mgr::resolve_model(text_det_model_path, true);
        if (!resolved.empty()) text_det_model_path = resolved;
        text_det_ctx = crispembed_text_det_init(text_det_model_path.c_str(), n_threads);
        if (!text_det_ctx)
            fprintf(stderr, "Warning: failed to load text detection model '%s'\n", text_det_model_path.c_str());
    }

    // NER (GLiNER)
    void * ner_ctx = nullptr;
    std::mutex ner_mutex;

    if (!ner_model_path.empty()) {
        std::string resolved = crispembed_mgr::resolve_model(ner_model_path, true);
        if (!resolved.empty()) ner_model_path = resolved;
        ner_ctx = crispembed_ner_init(ner_model_path.c_str(), n_threads);
        if (!ner_ctx) fprintf(stderr, "Warning: failed to load NER model '%s'\n", ner_model_path.c_str());
    }

    // Text LID
#if SERVER_HAS_LID
    text_lid_context * lid_ctx = nullptr;
    std::mutex lid_mutex;

    if (!lid_model_path.empty()) {
        std::string resolved = crispembed_mgr::resolve_model(lid_model_path, true);
        if (!resolved.empty()) lid_model_path = resolved;
        lid_ctx = text_lid_init_from_file(lid_model_path.c_str(), n_threads);
        if (!lid_ctx) fprintf(stderr, "Warning: failed to load LID model '%s'\n", lid_model_path.c_str());
    }
#endif

    // KIE (OCR + NER pipeline) — auto-enabled when NER + OCR det/rec are all loaded.
    void * kie_ctx = nullptr;
    std::mutex kie_mutex;

    if (ner_ctx && !ocr_det_model_path.empty() && !ocr_rec_model_path.empty()) {
        kie_ctx = crispembed_kie_init(ocr_det_model_path.c_str(), ocr_rec_model_path.c_str(), ner_model_path.c_str(),
                                      n_threads);
        if (!kie_ctx) fprintf(stderr, "Warning: failed to init KIE pipeline\n");
    }

    // ── Text Super-Resolution ──
    void * text_sr_ctx = nullptr;
    std::mutex text_sr_mutex;

    if (!sr_model_path.empty()) {
        text_sr_ctx = crispembed_text_sr_init(sr_model_path.c_str(), n_threads);
        if (!text_sr_ctx) fprintf(stderr, "Warning: failed to load text SR model '%s'\n", sr_model_path.c_str());
    }

    // ── PAN Super-Resolution ──
    void * pan_sr_ctx = nullptr;
    std::mutex pan_sr_mutex;

    if (!pan_model_path.empty()) {
        pan_sr_ctx = crispembed_pan_sr_init(pan_model_path.c_str(), n_threads);
        if (!pan_sr_ctx) fprintf(stderr, "Warning: failed to load PAN SR model '%s'\n", pan_model_path.c_str());
    }

    // ── SAM 2.1 segmentation ──
    void * sam2_ctx = nullptr;
    std::mutex sam2_mutex;
    if (!sam2_model_path.empty()) {
        const std::string resolved = crispembed_mgr::resolve_model(sam2_model_path, true);
        if (!resolved.empty()) sam2_ctx = crispembed_sam2_init(resolved.c_str(), n_threads);
        if (!sam2_ctx) fprintf(stderr, "Warning: failed to load SAM 2 model '%s'\n", sam2_model_path.c_str());
    }

    // ── HAT Super-Resolution ──
    void * hat_sr_ctx = nullptr;
    std::mutex hat_sr_mutex;

    if (!hat_model_path.empty()) {
        hat_sr_ctx = crispembed_hat_sr_init(hat_model_path.c_str(), n_threads);
        if (!hat_sr_ctx) fprintf(stderr, "Warning: failed to load HAT SR model '%s'\n", hat_model_path.c_str());
    }

    // ── DAT Super-Resolution ──
    void * dat_sr_ctx = nullptr;
    std::mutex dat_sr_mutex;

    if (!dat_model_path.empty()) {
        dat_sr_ctx = crispembed_dat_sr_init(dat_model_path.c_str(), n_threads);
        if (!dat_sr_ctx) fprintf(stderr, "Warning: failed to load DAT SR model '%s'\n", dat_model_path.c_str());
    }

    // ── SAFMN Super-Resolution ──
    void * safmn_sr_ctx = nullptr;
    std::mutex safmn_sr_mutex;

    if (!safmn_model_path.empty()) {
        safmn_sr_ctx = crispembed_safmn_sr_init(safmn_model_path.c_str(), n_threads);
        if (!safmn_sr_ctx) fprintf(stderr, "Warning: failed to load SAFMN SR model '%s'\n", safmn_model_path.c_str());
    }

    // ── Real-ESRGAN Super-Resolution ──
    void * esrgan_sr_ctx = nullptr;
    std::mutex esrgan_sr_mutex;

    if (!esrgan_model_path.empty()) {
        esrgan_sr_ctx = crispembed_esrgan_sr_init(esrgan_model_path.c_str(), n_threads);
        if (!esrgan_sr_ctx)
            fprintf(stderr, "Warning: failed to load Real-ESRGAN SR model '%s'\n", esrgan_model_path.c_str());
    }

    // ── SwinIR Super-Resolution ──
    void * swinir_sr_ctx = nullptr;
    std::mutex swinir_sr_mutex;

    if (!swinir_model_path.empty()) {
        swinir_sr_ctx = crispembed_swinir_sr_init(swinir_model_path.c_str(), n_threads);
        if (!swinir_sr_ctx)
            fprintf(stderr, "Warning: failed to load SwinIR SR model '%s'\n", swinir_model_path.c_str());
    }

    // ── TBSRN text-line Super-Resolution ──
    void * tbsrn_sr_ctx = nullptr;
    std::mutex tbsrn_sr_mutex;

    if (!tbsrn_model_path.empty()) {
        tbsrn_sr_ctx = crispembed_tbsrn_sr_init(tbsrn_model_path.c_str(), n_threads);
        if (!tbsrn_sr_ctx) fprintf(stderr, "Warning: failed to load TBSRN SR model '%s'\n", tbsrn_model_path.c_str());
    }

    // ── Restormer image restoration ──
    void * restormer_ctx = nullptr;
    std::mutex restormer_mutex;

    if (!restormer_model_path.empty()) {
        restormer_ctx = crispembed_restormer_init(restormer_model_path.c_str(), n_threads);
        if (!restormer_ctx)
            fprintf(stderr, "Warning: failed to load Restormer model '%s'\n", restormer_model_path.c_str());
    }

    // ── SCUNet image denoising ──
    void * scunet_ctx = nullptr;
    std::mutex scunet_mutex;

    if (!scunet_model_path.empty()) {
        scunet_ctx = crispembed_scunet_init(scunet_model_path.c_str(), n_threads);
        if (!scunet_ctx) fprintf(stderr, "Warning: failed to load SCUNet model '%s'\n", scunet_model_path.c_str());
    }

    // ── InstructIR all-in-one restoration ──
    void * instructir_ctx = nullptr;
    std::mutex instructir_mutex;

    if (!instructir_model_path.empty()) {
        instructir_ctx = crispembed_instructir_init(instructir_model_path.c_str(), n_threads);
        if (!instructir_ctx)
            fprintf(stderr, "Warning: failed to load InstructIR model '%s'\n", instructir_model_path.c_str());
    }

    // ── AdaIR all-in-one restoration ──
    void * adair_ctx = nullptr;
    std::mutex adair_mutex;

    if (!adair_model_path.empty()) {
        adair_ctx = crispembed_adair_init(adair_model_path.c_str(), n_threads);
        if (!adair_ctx) fprintf(stderr, "Warning: failed to load AdaIR model '%s'\n", adair_model_path.c_str());
    }

    // POST /clip/text — CLIP text encoding
    // Request:  {"text": "a photo of a cat"}
    // Response: {"embedding": [...], "dim": N}
    svr.Post("/clip/text", [&](const httplib::Request & req, httplib::Response & res) {
        if (!clip_text_ctx) {
            res.status = 503;
            res.set_content("{\"error\": \"no CLIP text model loaded (use --clip-text)\"}", "application/json");
            return;
        }

        auto body = req.body;
        std::string text;
        {
            std::vector<std::string> vals;
            if (json_extract_strings(body, "text", vals) > 0) text = vals[0];
        }
        if (text.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"no text\"}", "application/json");
            return;
        }

        std::lock_guard<std::mutex> lock(clip_text_mutex);
        auto t0 = std::chrono::steady_clock::now();

        int d = 0;
        const float * vec = crispembed_clip_text_encode(clip_text_ctx, text.c_str(), &d);
        if (!vec || d <= 0) {
            res.status = 500;
            res.set_content("{\"error\": \"CLIP text encoding failed\"}", "application/json");
            return;
        }

        auto t1 = std::chrono::steady_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        std::ostringstream js;
        js << "{\"embedding\": [";
        for (int j = 0; j < d; j++) {
            if (j > 0) js << ", ";
            js << vec[j];
        }
        js << "], \"dim\": " << d << "}";

        fprintf(stderr, "crispembed-server: /clip/text in %.1f ms (dim=%d)\n", ms, d);
        res.set_content(js.str(), "application/json");
    });

    // POST /colbert/score — ColBERT late interaction scoring
    // Request:  {"query": "search text", "documents": ["doc1", "doc2", ...]}
    // Response: {"scores": [{"index": 0, "score": 12.5, "text": "doc1"}, ...], "ms": 5.2}
    svr.Post("/colbert/score", [&](const httplib::Request & req, httplib::Response & res) {
        if (!ctx) {
            res.status = 503;
            res.set_content("{\"error\": \"no embedding model loaded\"}", "application/json");
            return;
        }
        if (!crispembed_has_colbert(ctx)) {
            res.status = 400;
            res.set_content("{\"error\": \"loaded model does not support ColBERT\"}", "application/json");
            return;
        }

        // Parse query text (JSON-escaping aware)
        std::string query_text;
        {
            std::vector<std::string> q;
            if (json_extract_strings(req.body, "query", q) > 0) query_text = q.front();
        }
        if (query_text.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"missing query field\"}", "application/json");
            return;
        }

        // Parse documents array (JSON-escaping aware)
        std::vector<std::string> doc_texts;
        json_extract_strings(req.body, "documents", doc_texts);
        if (doc_texts.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"no documents provided\"}", "application/json");
            return;
        }

        // Check if client wants SSE streaming
        bool stream =
            req.has_header("Accept") && req.get_header_value("Accept").find("text/event-stream") != std::string::npos;

        std::lock_guard<std::mutex> lock(model_mutex);
        auto t0 = std::chrono::high_resolution_clock::now();

        // Encode query
        int n_query = 0, qdim = 0;
        const float * query_vecs = crispembed_encode_multivec(ctx, query_text.c_str(), &n_query, &qdim);
        if (!query_vecs || n_query == 0) {
            res.status = 500;
            res.set_content("{\"error\": \"failed to encode query\"}", "application/json");
            return;
        }

        // Copy query vecs (encode_multivec invalidates previous pointer)
        std::vector<float> query_copy(query_vecs, query_vecs + n_query * qdim);

        if (stream) {
            // SSE streaming: emit each document score as it's computed
            auto shared_docs = std::make_shared<std::vector<std::string>>(std::move(doc_texts));
            auto shared_query = std::make_shared<std::vector<float>>(std::move(query_copy));
            auto shared_n_query = n_query;
            auto shared_qdim = qdim;
            auto shared_t0 = t0;

            res.set_chunked_content_provider(
                "text/event-stream",
                [shared_docs, shared_query, shared_n_query, shared_qdim, shared_t0, &ctx,
                 &model_mutex](size_t /*offset*/, httplib::DataSink & sink) -> bool {
                    for (int i = 0; i < (int)shared_docs->size(); i++) {
                        int n_doc = 0, ddim = 0;
                        const float * doc_vecs =
                            crispembed_encode_multivec(ctx, (*shared_docs)[i].c_str(), &n_doc, &ddim);
                        float score = 0;
                        if (doc_vecs && n_doc > 0 && ddim == shared_qdim)
                            score = crispembed_colbert_score(shared_query->data(), shared_n_query, doc_vecs, n_doc,
                                                             shared_qdim);

                        // Escape text
                        std::string escaped;
                        for (char c : (*shared_docs)[i]) {
                            if (c == '"')
                                escaped += "\\\"";
                            else if (c == '\\')
                                escaped += "\\\\";
                            else if (c == '\n')
                                escaped += "\\n";
                            else
                                escaped += c;
                        }

                        std::ostringstream ev;
                        ev << "data: {\"index\": " << i << ", \"score\": " << score << ", \"text\": \"" << escaped
                           << "\"}\n\n";
                        sink.write(ev.str().c_str(), ev.str().size());
                    }

                    auto t1 = std::chrono::high_resolution_clock::now();
                    double ms = std::chrono::duration<double, std::milli>(t1 - shared_t0).count();
                    std::ostringstream ev;
                    ev << "event: done\ndata: {\"ms\": " << ms << "}\n\n";
                    sink.write(ev.str().c_str(), ev.str().size());
                    sink.done();
                    return true;
                });

            fprintf(stderr, "crispembed-server: /colbert/score SSE %d docs\n", (int)shared_docs->size());
        } else {
            // Non-streaming: score all, sort, return JSON
            struct scored_doc {
                int index;
                float score;
            };
            std::vector<scored_doc> results;
            results.reserve(doc_texts.size());

            for (int i = 0; i < (int)doc_texts.size(); i++) {
                int n_doc = 0, ddim = 0;
                const float * doc_vecs = crispembed_encode_multivec(ctx, doc_texts[i].c_str(), &n_doc, &ddim);
                if (!doc_vecs || n_doc == 0 || ddim != qdim) {
                    results.push_back({ i, 0.0f });
                    continue;
                }
                float score = crispembed_colbert_score(query_copy.data(), n_query, doc_vecs, n_doc, qdim);
                results.push_back({ i, score });
            }

            std::sort(results.begin(), results.end(),
                      [](const scored_doc & a, const scored_doc & b) { return a.score > b.score; });

            auto t1 = std::chrono::high_resolution_clock::now();
            double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

            std::ostringstream js;
            js << "{\"scores\": [";
            for (size_t i = 0; i < results.size(); i++) {
                if (i > 0) js << ", ";
                std::string escaped;
                for (char c : doc_texts[results[i].index]) {
                    if (c == '"')
                        escaped += "\\\"";
                    else if (c == '\\')
                        escaped += "\\\\";
                    else if (c == '\n')
                        escaped += "\\n";
                    else
                        escaped += c;
                }
                js << "{\"index\": " << results[i].index << ", \"score\": " << results[i].score << ", \"text\": \""
                   << escaped << "\"" << "}";
            }
            js << "], \"ms\": " << ms << "}";

            fprintf(stderr, "crispembed-server: /colbert/score %d docs in %.1f ms\n", (int)doc_texts.size(), ms);
            res.set_content(js.str(), "application/json");
        }
    });

    // POST /rerank      — native shape (issue #37).
    // POST /v1/rerank   — Cohere / Jina compatible shape (issue #51).
    // Both share handle_rerank_request(); see its comment for the two
    // deliberate differences (sigmoid relevance_score, opt-in documents).
    svr.Post("/rerank", [&](const httplib::Request & req, httplib::Response & res) {
        handle_rerank_request(req, res, ctx, model_mutex, model_name, /*cohere_shape=*/false);
    });
    svr.Post("/v1/rerank", [&](const httplib::Request & req, httplib::Response & res) {
        handle_rerank_request(req, res, ctx, model_mutex, model_name, /*cohere_shape=*/true);
    });

    // POST /sparse — SPLADE / BGE-M3 sparse term-weight retrieval. The loaded model
    // must expose a sparse head (has_sparse == 1). Returns the non-zero vocabulary
    // term weights per input text (SPLADE-style bag of weighted expansion terms).
    // Request:  {"texts": ["your query text"]}   (or {"text": "..."})
    // Response: {"results": [{"weights": {"1996": 0.9532, "2938": 1.5153}}]}
    svr.Post("/sparse", [&](const httplib::Request & req, httplib::Response & res) {
        if (!ctx) {
            res.status = 503;
            res.set_content("{\"error\": \"no embedding model loaded\"}", "application/json");
            return;
        }
        if (!crispembed_has_sparse(ctx)) {
            res.status = 400;
            res.set_content("{\"error\": \"loaded model does not support sparse retrieval\"}", "application/json");
            return;
        }

        std::vector<std::string> texts;
        if (json_extract_strings(req.body, "texts", texts) == 0) {
            json_extract_strings(req.body, "text", texts);
        }
        if (texts.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"no texts provided\"}", "application/json");
            return;
        }

        std::lock_guard<std::mutex> lock(model_mutex);
        auto t0 = std::chrono::steady_clock::now();

        std::ostringstream js;
        js << "{\"results\": [";
        for (size_t t = 0; t < texts.size(); ++t) {
            const int32_t * indices = nullptr;
            const float * values = nullptr;
            const int n = crispembed_encode_sparse(ctx, texts[t].c_str(), &indices, &values);
            if (t > 0) js << ", ";
            js << "{\"weights\": {";
            for (int i = 0; i < n; ++i) {
                if (i > 0) js << ", ";
                js << "\"" << indices[i] << "\": " << std::fixed << std::setprecision(6) << values[i];
            }
            js << "}}";
        }
        js << "]}";
        double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
        fprintf(stderr, "crispembed-server: /sparse %zu texts in %.1f ms\n", texts.size(), ms);
        res.set_content(js.str(), "application/json");
    });

    // PDF/image path confinement is shared with the existing image endpoints.
    // A complete response owns its output, metadata and base64 PNG assets.
    svr.Post("/ocr/marker", [&](const httplib::Request & req, httplib::Response & res) {
        if (!marker_ctx) {
            res.status = 503;
            res.set_content("{\"error\":\"Marker is not configured\"}", "application/json");
            return;
        }
        const std::string file = extract_path_field(req.body, "file", g_image_root, "--image-root");
        std::vector<std::string> formats;
        json_extract_strings(req.body, "format", formats);
        const std::string format = formats.empty() ? "json" : formats.front();
        if (file.empty() || (format != "markdown" && format != "html" && format != "json" && format != "chunks")) {
            res.status = 400;
            res.set_content("{\"error\":\"valid file path and markdown/html/json/chunks format required\"}", "application/json");
            return;
        }
        std::lock_guard<std::mutex> lock(marker_mutex);
        if (!crispembed_marker_convert(marker_ctx, file.c_str())) {
            res.status = 422;
            res.set_content("{\"error\":\"" + core_json::json_escape_strict(crispembed_marker_error(marker_ctx)) + "\"}", "application/json");
            return;
        }
        const char * rendered = crispembed_marker_render(marker_ctx, format.c_str());
        if (!rendered) {
            res.status = 500;
            res.set_content("{\"error\":\"" + core_json::json_escape_strict(crispembed_marker_error(marker_ctx)) + "\"}", "application/json");
            return;
        }
        std::ostringstream out;
        out << "{\"format\":\"" << format << "\",\"output\":\"" << core_json::json_escape_strict(rendered)
            << "\",\"metadata\":" << crispembed_marker_metadata(marker_ctx) << ",\"images\":{";
        const char * alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        const int count = crispembed_marker_asset_count(marker_ctx);
        for (int i = 0; i < count; ++i) {
            if (i) out << ',';
            size_t size = 0;
            const auto * data = crispembed_marker_asset_data(marker_ctx, i, &size);
            out << '\"' << core_json::json_escape_strict(crispembed_marker_asset_name(marker_ctx, i)) << "\":\"data:image/png;base64,";
            for (size_t j = 0; j < size; j += 3) {
                const unsigned v = (unsigned(data[j]) << 16) | (j + 1 < size ? unsigned(data[j + 1]) << 8 : 0) |
                                   (j + 2 < size ? unsigned(data[j + 2]) : 0);
                out << alphabet[(v >> 18) & 63] << alphabet[(v >> 12) & 63]
                    << (j + 1 < size ? alphabet[(v >> 6) & 63] : '=') << (j + 2 < size ? alphabet[v & 63] : '=');
            }
            out << '\"';
        }
        out << "}}";
        res.set_content(out.str(), "application/json");
    });

    // POST /ocr/model — single-model OCR recognition (math or text, auto-dispatched).
    // /math/ocr is kept as a deprecated alias for the same handler.
    // Request:  {"image": "/path/to/formula.png"}
    // Response: {"latex": "\\frac{a}{b}", "len": 12, "ms": 450.2}
    auto ocr_model_handler = [&](const httplib::Request & req, httplib::Response & res) {
        if (!ocr_model_ctx) {
            res.status = 503;
            res.set_content("{\"error\": \"no OCR model loaded (use --ocr)\"}", "application/json");
            return;
        }

        auto body = req.body;
        std::string image_path;
        image_path = extract_image_path(body);
        if (image_path.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"no image path\"}", "application/json");
            return;
        }

        int req_max_tokens = 0;
        req_max_tokens = (int)json_extract_number(body, "max_tokens", req_max_tokens);
        // Optional per-request instruction for prompt-following VLMs. It is
        // applied for this request only; the startup --ocr-prompt (or the
        // engine default) is restored afterwards so one client's instruction
        // does not leak into the next request on the shared context.
        std::string req_prompt;
        {
            std::vector<std::string> pv;
            if (json_extract_strings(body, "prompt", pv) > 0) req_prompt = pv.front();
        }

        std::lock_guard<std::mutex> lock(ocr_model_mutex);
        const bool has_generation_params =
            core_json::json_find_key_value(body, "repetition_penalty") != std::string::npos ||
            core_json::json_find_key_value(body, "presence_penalty") != std::string::npos ||
            core_json::json_find_key_value(body, "frequency_penalty") != std::string::npos ||
            core_json::json_find_key_value(body, "no_repeat_ngram") != std::string::npos;
        float previous_repetition = 0, previous_presence = 0, previous_frequency = 0;
        int previous_ngram = 0;
        if (has_generation_params) {
            if (!crispembed_ocr_model_get_generation_params(ocr_model_ctx, &previous_repetition, &previous_presence,
                                                            &previous_frequency, &previous_ngram)) {
                res.status = 400;
                res.set_content("{\"error\":\"generation penalties require a TeleOCR model\"}", "application/json");
                return;
            }
            auto penalty = [&](const char * key, double fallback) {
                return core_json::json_find_key_value(body, key) == std::string::npos
                           ? fallback
                           : json_extract_number(body, key, std::numeric_limits<double>::quiet_NaN());
            };
            const double rep = penalty("repetition_penalty", previous_repetition);
            const double pres = penalty("presence_penalty", previous_presence);
            const double freq = penalty("frequency_penalty", previous_frequency);
            const double ngram = penalty("no_repeat_ngram", previous_ngram);
            if (!std::isfinite(rep) || !std::isfinite(pres) || !std::isfinite(freq) || !std::isfinite(ngram) ||
                ngram < 0 || ngram > 4096 || std::floor(ngram) != ngram ||
                !crispembed_ocr_model_set_generation_params(ocr_model_ctx, (float)rep, (float)pres, (float)freq,
                                                            (int)ngram)) {
                res.status = 400;
                res.set_content("{\"error\":\"invalid TeleOCR generation penalties\"}", "application/json");
                return;
            }
        }
        const int previous_max_tokens = crispembed_ocr_model_get_max_tokens(ocr_model_ctx);
        if (req_max_tokens > 0) crispembed_ocr_model_set_max_tokens(ocr_model_ctx, req_max_tokens);
        int prompt_applied = -1; // -1 = no per-request prompt
        if (!req_prompt.empty()) prompt_applied = crispembed_ocr_model_set_prompt(ocr_model_ctx, req_prompt.c_str());
        struct request_state_restore {
            void * ctx;
            const std::string & dflt;
            int previous_max_tokens;
            bool prompt_active;
            bool max_tokens_active;
            bool generation_active;
            float repetition, presence, frequency;
            int ngram;
            ~request_state_restore() {
                if (prompt_active) crispembed_ocr_model_set_prompt(ctx, dflt.empty() ? nullptr : dflt.c_str());
                if (max_tokens_active) crispembed_ocr_model_set_max_tokens(ctx, previous_max_tokens);
                if (generation_active)
                    crispembed_ocr_model_set_generation_params(ctx, repetition, presence, frequency, ngram);
            }
        } restore{ ocr_model_ctx,       ocr_prompt,         previous_max_tokens,
                   prompt_applied == 1, req_max_tokens > 0, has_generation_params,
                   previous_repetition, previous_presence,  previous_frequency,
                   previous_ngram };
        auto t0 = std::chrono::steady_clock::now();

        int w = 0, h = 0, ch = 0;
        unsigned char * pixels = stbi_load(image_path.c_str(), &w, &h, &ch, 0);
        if (!pixels) {
            res.status = 400;
            res.set_content("{\"error\": \"failed to load image\"}", "application/json");
            return;
        }

        int out_len = 0;
        const char * latex = crispembed_ocr_model_recognize(ocr_model_ctx, pixels, w, h, ch, &out_len);
        stbi_image_free(pixels);

        // Fetch per-token and mean confidence scores after recognition.
        float mean_conf = crispembed_ocr_model_mean_confidence(ocr_model_ctx);
        int n_tok_conf = 0;
        const float * tok_conf = crispembed_ocr_model_confidences(ocr_model_ctx, &n_tok_conf);

        auto t1 = std::chrono::steady_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        std::ostringstream js;
        js << "{\"latex\": \"" << json_escape(latex ? latex : "") << "\", \"len\": " << out_len
           << ", \"confidence\": " << std::fixed << std::setprecision(4) << mean_conf << ", \"token_confidences\": [";
        for (int i = 0; i < n_tok_conf; i++) {
            if (i > 0) js << ",";
            js << std::fixed << std::setprecision(4) << tok_conf[i];
        }
        js << "]";
        if (prompt_applied >= 0) js << ", \"prompt_applied\": " << (prompt_applied ? "true" : "false");
        js << ", \"ms\": " << std::fixed << std::setprecision(1) << ms << "}";

        fprintf(stderr, "crispembed-server: /ocr/model in %.1f ms (%d chars, conf=%.2f)\n", ms, out_len, mean_conf);
        res.set_content(js.str(), "application/json");
    };
    svr.Post("/ocr/model", ocr_model_handler);
    svr.Post("/math/ocr", ocr_model_handler); // deprecated alias

    // POST /ocr — general text detection + recognition pipeline
    // Request:  {"image": "/path/to/document.png"}
    // Response: {"results": [{"text": "Hello", "bbox": [x,y,x2,y2], "confidence": 0.99}], "ms": M}
    svr.Post("/ocr", [&](const httplib::Request & req, httplib::Response & res) {
        if (!ocr_pipeline_ctx) {
            res.status = 503;
            res.set_content("{\"error\": \"OCR pipeline not loaded (use --ocr-det + --ocr-rec)\"}", "application/json");
            return;
        }
        auto body = req.body;
        std::string image_path;
        image_path = extract_image_path(body);
        if (image_path.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"missing 'image' field\"}", "application/json");
            return;
        }

        auto t0 = std::chrono::high_resolution_clock::now();

        std::lock_guard<std::mutex> lock(ocr_pipeline_mutex);
        int n_results = 0;
        const crispembed_ocr_result * results = crispembed_ocr(ocr_pipeline_ctx, image_path.c_str(), &n_results);

        auto t1 = std::chrono::high_resolution_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        std::ostringstream js;
        js << "{\"results\": [";
        for (int i = 0; i < n_results; i++) {
            if (i > 0) js << ",";
            js << "{\"text\":\"" << json_escape(results[i].text) << "\"" << ",\"bbox\":[" << results[i].x << ","
               << results[i].y << "," << (results[i].x + results[i].w) << "," << (results[i].y + results[i].h) << "]"
               << ",\"confidence\":" << results[i].confidence << ",\"rec_confidence\":" << results[i].confidence << "}";
        }
        js << "],\"n\":" << n_results << ",\"ms\":" << std::fixed << std::setprecision(1) << ms << "}";

        fprintf(stderr, "crispembed-server: /ocr in %.1f ms (%d regions)\n", ms, n_results);
        res.set_content(js.str(), "application/json");
    });

    // POST /ocr/pipeline — full orchestrator (routing + cleanup + accept-gate)
    // Request:  {"image": "/path/to/doc.png", "min_chars": 8, "min_confidence": 0.5}
    // Response: {"text": "...", "n_regions": N, "mean_confidence": F, "ms": M}
    // Note: per-request params override the context defaults when a fresh context
    // is built per call. Currently uses the shared ocr_orch_ctx (init-time config).
    svr.Post("/ocr/pipeline", [&](const httplib::Request & req, httplib::Response & res) {
        if (!ocr_orch_ctx) {
            res.status = 503;
            res.set_content(
                "{\"error\": \"OCR orchestrator not loaded (use --ocr-pipeline --ocr-det MODEL --ocr-rec MODEL)\"}",
                "application/json");
            return;
        }
        auto body = req.body;
        // Parse "image" (string)
        std::string image_path;
        image_path = extract_image_path(body);
        if (image_path.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"missing 'image' field\"}", "application/json");
            return;
        }

        auto t0 = std::chrono::high_resolution_clock::now();

        std::lock_guard<std::mutex> lock(ocr_orch_mutex);
        int n_results = 0;
        const char * full_text = nullptr;
        float mean_conf = 0.0f;
        const crispembed_ocr_result * results =
            crispembed_ocr_pipeline_run(ocr_orch_ctx, image_path.c_str(), &n_results, &full_text, &mean_conf);

        auto t1 = std::chrono::high_resolution_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        std::ostringstream js;
        js << "{\"text\":\"" << json_escape(full_text ? full_text : "") << "\"" << ",\"n_regions\":" << n_results
           << ",\"mean_confidence\":" << std::fixed << std::setprecision(4) << mean_conf << ",\"results\":[";
        for (int i = 0; i < n_results; i++) {
            if (i > 0) js << ",";
            float rec_conf = crispembed_ocr_pipeline_region_rec_confidence(ocr_orch_ctx, i);
            js << "{\"text\":\"" << json_escape(results[i].text) << "\"" << ",\"bbox\":[" << results[i].x << ","
               << results[i].y << "," << (results[i].x + results[i].w) << "," << (results[i].y + results[i].h) << "]"
               << ",\"confidence\":" << results[i].confidence << ",\"rec_confidence\":" << std::fixed
               << std::setprecision(4) << rec_conf << "}";
        }
        int n_order = 0;
        const int * order = crispembed_ocr_pipeline_reading_order(ocr_orch_ctx, &n_order);
        int markdown_len = 0;
        const char * markdown = crispembed_ocr_pipeline_markdown(ocr_orch_ctx, &markdown_len);
        js << "],\"reading_order\":[";
        for (int i = 0; i < n_order; ++i) {
            if (i) js << ",";
            js << order[i];
        }
        js << "],\"markdown\":\"" << json_escape(markdown ? markdown : "") << "\"" << ",\"ms\":" << std::fixed
           << std::setprecision(1) << ms << "}";

        fprintf(stderr, "crispembed-server: /ocr/pipeline in %.1f ms (%d regions, conf=%.2f)\n", ms, n_results,
                mean_conf);
        res.set_content(js.str(), "application/json");
    });

    // POST /layout/detect — document layout analysis
    // Request:  {"image": "/path/to/page.png", "threshold": 0.3}
    // Response: {"regions": [{"label": "text", "score": 0.95, "bbox": [x1, y1, x2, y2]}, ...]}
    svr.Post("/layout/detect", [&](const httplib::Request & req, httplib::Response & res) {
        if (!layout_ctx) {
            res.status = 503;
            res.set_content("{\"error\": \"no layout model loaded (use --layout)\"}", "application/json");
            return;
        }

        auto body = req.body;
        std::string image_path;
        float threshold = 0.3f;

        image_path = extract_image_path(body);
        threshold = (float)json_extract_number(body, "threshold", threshold);

        if (image_path.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"no image path\"}", "application/json");
            return;
        }

        std::lock_guard<std::mutex> lock(layout_mutex);
        auto t0 = std::chrono::steady_clock::now();

        int n_regions = 0;
        const crispembed_layout_region * regions =
            crispembed_layout_detect(layout_ctx, image_path.c_str(), threshold, &n_regions);

        auto t1 = std::chrono::steady_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        std::ostringstream js;
        js << "{\"regions\": [";
        for (int i = 0; i < n_regions; i++) {
            if (i > 0) js << ", ";
            js << "{\"label\": \"" << regions[i].label_name << "\", \"score\": " << std::fixed << std::setprecision(4)
               << regions[i].score << ", \"bbox\": [" << std::setprecision(1) << regions[i].x1 << ", " << regions[i].y1
               << ", " << regions[i].x2 << ", " << regions[i].y2 << "]}";
        }
        js << "], \"ms\": " << std::setprecision(1) << ms << "}";

        fprintf(stderr, "crispembed-server: /layout/detect in %.1f ms (%d regions)\n", ms, n_regions);
        res.set_content(js.str(), "application/json");
    });

    // POST /table/parse — rule-based table structure recognition
    // Request:  {"image": "/path/to/table.png"}
    // Response: {"html": "<table>...</table>", "ms": T}
    svr.Post("/table/parse", [&](const httplib::Request & req, httplib::Response & res) {
        auto body = req.body;
        std::string image_path;
        image_path = extract_image_path(body);
        if (image_path.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"no image path\"}", "application/json");
            return;
        }

        auto t0 = std::chrono::steady_clock::now();

        // Load image as grayscale
        int w = 0, h = 0, ch = 0;
        unsigned char * data = stbi_load(image_path.c_str(), &w, &h, &ch, 1);
        if (!data) {
            res.status = 400;
            res.set_content("{\"error\": \"cannot load image\"}", "application/json");
            return;
        }

        void * tctx = crispembed_table_parse_init(nullptr, n_threads);
        char * html = tctx ? crispembed_table_parse_to_html(tctx, data, w, h) : nullptr;
        stbi_image_free(data);

        auto t1 = std::chrono::steady_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        if (html) {
            std::ostringstream js;
            js << "{\"html\": \"" << json_escape(html) << "\", \"ms\": " << std::fixed << std::setprecision(1) << ms
               << "}";
            res.set_content(js.str(), "application/json");
            crispembed_table_parse_free_string(html);
        } else {
            res.set_content("{\"error\": \"table parsing failed\"}", "application/json");
        }
        if (tctx) crispembed_table_parse_free(tctx);

        fprintf(stderr, "crispembed-server: /table/parse in %.1f ms\n", ms);
    });

    // POST /text/detect — surya text line detection
    // Request:  {"image": "/path/to/page.png", "threshold": 0.6}
    // Response: {"boxes": [{"bbox": [x0, y0, x1, y1], "confidence": 0.95}, ...]}
    svr.Post("/text/detect", [&](const httplib::Request & req, httplib::Response & res) {
        if (!text_det_ctx) {
            res.status = 503;
            res.set_content("{\"error\": \"no text detection model loaded (use --text-det)\"}", "application/json");
            return;
        }

        auto body = req.body;
        std::string image_path;
        float threshold = 0.6f;

        image_path = extract_image_path(body);
        threshold = (float)json_extract_number(body, "threshold", threshold);

        if (image_path.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"no image path\"}", "application/json");
            return;
        }

        // Load image via stb_image
        int w, h, ch;
        unsigned char * px = stbi_load(image_path.c_str(), &w, &h, &ch, 3);
        if (!px) {
            res.status = 400;
            res.set_content("{\"error\": \"cannot load image\"}", "application/json");
            return;
        }

        std::lock_guard<std::mutex> lock(text_det_mutex);
        auto t0 = std::chrono::steady_clock::now();

        int n_boxes = 0;
        const crispembed_text_det_result * boxes =
            crispembed_text_det(text_det_ctx, px, w, h, 3, threshold, 0.35f, &n_boxes);
        stbi_image_free(px);

        auto t1 = std::chrono::steady_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        std::ostringstream js;
        js << "{\"boxes\": [";
        for (int i = 0; i < n_boxes; i++) {
            if (i > 0) js << ", ";
            js << "{\"bbox\": [" << std::fixed << std::setprecision(1) << boxes[i].x0 << ", " << boxes[i].y0 << ", "
               << boxes[i].x1 << ", " << boxes[i].y1 << "], \"confidence\": " << std::setprecision(4)
               << boxes[i].confidence << "}";
        }
        js << "], \"ms\": " << std::setprecision(1) << ms << "}";

        fprintf(stderr, "crispembed-server: /text/detect in %.1f ms (%d boxes)\n", ms, n_boxes);
        res.set_content(js.str(), "application/json");
    });

    // POST /ner/extract — zero-shot named entity recognition
    // Request:  {"text": "Barack Obama was born in Hawaii", "labels": ["person", "location"], "threshold": 0.5}
    // Response: {"entities": [{"text": "Barack Obama", "label": "person", "start": 0, "end": 12, "score": 0.56}]}
    svr.Post("/ner/extract", [&](const httplib::Request & req, httplib::Response & res) {
        if (!ner_ctx) {
            res.status = 503;
            res.set_content("{\"error\": \"no NER model loaded (use --ner)\"}", "application/json");
            return;
        }

        auto body = req.body;

        // Parse "text"
        std::string text;
        {
            std::vector<std::string> vals;
            if (json_extract_strings(body, "text", vals) > 0) text = vals[0];
        }

        // Parse "labels" array
        std::vector<std::string> labels;
        json_extract_strings(body, "labels", labels);

        // Parse "threshold"
        float threshold = 0.5f;
        { threshold = (float)json_extract_number(body, "threshold", threshold); }

        if (text.empty() || labels.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"provide \\\"text\\\" and \\\"labels\\\" fields\"}", "application/json");
            return;
        }

        std::vector<const char *> label_ptrs(labels.size());
        for (size_t i = 0; i < labels.size(); i++) label_ptrs[i] = labels[i].c_str();

        std::lock_guard<std::mutex> lock(ner_mutex);
        auto t0 = std::chrono::steady_clock::now();

        crispembed_ner_entity * entities = nullptr;
        int n =
            crispembed_ner_extract(ner_ctx, text.c_str(), label_ptrs.data(), (int)labels.size(), threshold, &entities);

        auto t1 = std::chrono::steady_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        std::ostringstream js;
        js << "{\"entities\": [";
        for (int i = 0; i < n; i++) {
            if (i > 0) js << ", ";
            js << "{\"text\": \"" << json_escape(entities[i].text ? entities[i].text : "") << "\", \"label\": \""
               << json_escape(entities[i].label ? entities[i].label : "") << "\", \"start\": " << entities[i].start_char
               << ", \"end\": " << entities[i].end_char << ", \"score\": " << std::fixed << std::setprecision(4)
               << entities[i].score << "}";
        }
        js << "], \"ms\": " << std::setprecision(1) << ms << "}";

        fprintf(stderr, "crispembed-server: /ner/extract in %.1f ms (%d entities)\n", ms, n);
        res.set_content(js.str(), "application/json");
    });

    // POST /lid/detect — text language identification
    // Request:  {"text": "Hallo Welt, wie geht es Ihnen?"}
    // Response: {"lang": "de", "confidence": 0.99, "ms": T}
#if SERVER_HAS_LID
    svr.Post("/lid/detect", [&](const httplib::Request & req, httplib::Response & res) {
        if (!lid_ctx) {
            res.status = 503;
            res.set_content("{\"error\": \"no LID model loaded (use --lid)\"}", "application/json");
            return;
        }

        auto body = req.body;
        std::string text;
        {
            std::vector<std::string> vals;
            if (json_extract_strings(body, "text", vals) > 0) text = vals[0];
        }

        if (text.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"provide \\\"text\\\" field\"}", "application/json");
            return;
        }

        std::lock_guard<std::mutex> lock(lid_mutex);
        auto t0 = std::chrono::steady_clock::now();

        float conf = 0.0f;
        const char * lang = text_lid_predict(lid_ctx, text.c_str(), &conf);

        auto t1 = std::chrono::steady_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        std::ostringstream js;
        js << "{\"lang\": \"" << (lang ? lang : "") << "\"" << ", \"confidence\": " << std::fixed
           << std::setprecision(4) << conf << ", \"ms\": " << std::setprecision(1) << ms << "}";

        fprintf(stderr, "crispembed-server: /lid/detect → %s (%.2f) in %.1f ms\n", lang ? lang : "?", conf, ms);
        res.set_content(js.str(), "application/json");
    });
#endif

    // POST /kie/extract — key information extraction (OCR + NER)
    // Request:  {"image": "/path/to/doc.png", "labels": ["total", "date", "vendor"], "threshold": 0.5}
    // Response: {"fields": [{label, value, score, bbox}], "ocr_text": "...", "ocr_confidence": 0.85, "n_ocr_regions": 12}
    svr.Post("/kie/extract", [&](const httplib::Request & req, httplib::Response & res) {
        if (!kie_ctx) {
            res.status = 503;
            res.set_content("{\"error\": \"KIE not available (need --ner + --ocr-det + --ocr-rec)\"}",
                            "application/json");
            return;
        }

        auto body = req.body;

        // Parse "image"
        std::string image_path;
        { image_path = extract_image_path(body); }

        // Parse "labels" array
        std::vector<std::string> labels;
        json_extract_strings(body, "labels", labels);

        // Parse "threshold"
        float threshold = 0.5f;
        { threshold = (float)json_extract_number(body, "threshold", threshold); }

        if (image_path.empty() || labels.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"provide \\\"image\\\" and \\\"labels\\\" fields\"}", "application/json");
            return;
        }

        std::vector<const char *> label_ptrs(labels.size());
        for (size_t i = 0; i < labels.size(); i++) label_ptrs[i] = labels[i].c_str();

        std::lock_guard<std::mutex> lock(kie_mutex);
        auto t0 = std::chrono::steady_clock::now();

        crispembed_kie_result kr =
            crispembed_kie_extract(kie_ctx, image_path.c_str(), label_ptrs.data(), (int)labels.size(), threshold);

        auto t1 = std::chrono::steady_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        std::ostringstream js;
        js << "{\"fields\": [";
        for (int i = 0; i < kr.n_fields; i++) {
            if (i > 0) js << ", ";
            js << "{\"label\": \"" << json_escape(kr.fields[i].label ? kr.fields[i].label : "") << "\", \"value\": \""
               << json_escape(kr.fields[i].value ? kr.fields[i].value : "") << "\", \"score\": " << std::fixed
               << std::setprecision(4) << kr.fields[i].score << ", \"bbox\": [" << std::setprecision(1)
               << kr.fields[i].x << ", " << kr.fields[i].y << ", " << kr.fields[i].w << ", " << kr.fields[i].h << "]}";
        }
        js << "], \"ocr_text\": \"" << json_escape(kr.ocr_text ? kr.ocr_text : "")
           << "\", \"ocr_confidence\": " << std::setprecision(3) << kr.ocr_confidence
           << ", \"n_ocr_regions\": " << kr.n_ocr_regions << ", \"ms\": " << std::setprecision(1) << ms << "}";

        fprintf(stderr, "crispembed-server: /kie/extract in %.1f ms (%d fields)\n", ms, kr.n_fields);
        res.set_content(js.str(), "application/json");
    });

    // POST /scan/cleanup — document scan preprocessing (no model needed)
    // Request:  {"image": "/path/to/scan.png", "deskew": true, "binarize": false}
    // Response: {"width": W, "height": H, "original_width": OW, "original_height": OH, "ms": T}
    svr.Post("/scan/cleanup", [&](const httplib::Request & req, httplib::Response & res) {
        auto body = req.body;
        std::string image_path;

        image_path = extract_image_path(body);

        if (image_path.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"missing 'image' field\"}", "application/json");
            return;
        }

        int w, h, ch;
        unsigned char * data = stbi_load(image_path.c_str(), &w, &h, &ch, 0);
        if (!data) {
            res.status = 400;
            res.set_content("{\"error\": \"cannot load image\"}", "application/json");
            return;
        }

        auto t0 = std::chrono::steady_clock::now();

        auto params = scan_cleanup_defaults();
        // Parse optional params from JSON
        auto parse_bool = [&](const char * key) -> int {
            auto p = body.find(key);
            if (p == std::string::npos) return -1;
            auto c = body.find(':', p);
            if (c == std::string::npos) return -1;
            auto v = body.find_first_not_of(" \t\n", c + 1);
            if (v == std::string::npos) return -1;
            return (body[v] == 't' || body[v] == '1') ? 1 : 0;
        };
        int v;
        if ((v = parse_bool("\"deskew\"")) >= 0) params.deskew = v;
        if ((v = parse_bool("\"crop_borders\"")) >= 0) params.crop_borders = v;
        if ((v = parse_bool("\"whiten_background\"")) >= 0) params.whiten_background = v;
        if ((v = parse_bool("\"binarize\"")) >= 0) params.binarize = v;

        auto * sctx = scan_cleanup_init(nullptr, 4);
        uint8_t * out = nullptr;
        int ow = 0, oh = 0;
        int rc = scan_cleanup_process(sctx, data, w, h, ch, params, &out, &ow, &oh);
        scan_cleanup_free(sctx);
        stbi_image_free(data);

        auto t1 = std::chrono::steady_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        if (rc != 0 || !out) {
            res.status = 500;
            res.set_content("{\"error\": \"scan cleanup failed\"}", "application/json");
            return;
        }

        scan_cleanup_free_image(out);

        std::ostringstream js;
        js << "{\"width\": " << ow << ", \"height\": " << oh << ", \"original_width\": " << w
           << ", \"original_height\": " << h << ", \"ms\": " << std::setprecision(1) << std::fixed << ms << "}";

        fprintf(stderr, "crispembed-server: /scan/cleanup in %.1f ms (%dx%d -> %dx%d)\n", ms, w, h, ow, oh);
        res.set_content(js.str(), "application/json");
    });

    // NOTE: there used to be a local `extract_image_path` lambda here. It read
    // the field correctly but skipped path_within(), and being declared at
    // function scope it SHADOWED the file-scope extract_image_path() for every
    // handler registered below it — so --image-root confined the 13 endpoints
    // above this point (including /face and /detect) and silently missed the 20
    // below, among them every super-resolution and restoration engine. Do not
    // reintroduce a same-named local: the file-scope version is the one that
    // confines, and shadowing it fails open without a diagnostic.

    // POST /scan/split — detect a two-up book spread (no model needed)
    // Request:  {"image": "/path/to/scan.png"}
    // Response: {"pages": 1|2, "split_x": X (if 2), "width": W, "height": H}
    svr.Post("/scan/split", [&](const httplib::Request & req, httplib::Response & res) {
        std::string image_path = extract_image_path(req.body);
        if (image_path.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"missing 'image' field\"}", "application/json");
            return;
        }
        int w, h, ch;
        unsigned char * data = stbi_load(image_path.c_str(), &w, &h, &ch, 0);
        if (!data) {
            res.status = 400;
            res.set_content("{\"error\": \"cannot load image\"}", "application/json");
            return;
        }
        int sx = scan_cleanup_detect_page_split(data, w, h, ch);
        stbi_image_free(data);
        std::ostringstream js;
        if (sx < 0)
            js << "{\"pages\": 1, \"width\": " << w << ", \"height\": " << h << "}";
        else
            js << "{\"pages\": 2, \"split_x\": " << sx << ", \"width\": " << w << ", \"height\": " << h << "}";
        res.set_content(js.str(), "application/json");
    });

    // POST /scan/content — detect the printed content bounding box (no model needed)
    // Request:  {"image": "/path/to/scan.png"}
    // Response: {"content": true, "x0":.., "y0":.., "x1":.., "y1":..} | {"content": false}
    svr.Post("/scan/content", [&](const httplib::Request & req, httplib::Response & res) {
        std::string image_path = extract_image_path(req.body);
        if (image_path.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"missing 'image' field\"}", "application/json");
            return;
        }
        int w, h, ch;
        unsigned char * data = stbi_load(image_path.c_str(), &w, &h, &ch, 0);
        if (!data) {
            res.status = 400;
            res.set_content("{\"error\": \"cannot load image\"}", "application/json");
            return;
        }
        int x0, y0, x1, y1;
        int rc = scan_cleanup_content_bbox(data, w, h, ch, &x0, &y0, &x1, &y1);
        stbi_image_free(data);
        std::ostringstream js;
        if (rc != 0)
            js << "{\"content\": false, \"width\": " << w << ", \"height\": " << h << "}";
        else
            js << "{\"content\": true, \"x0\": " << x0 << ", \"y0\": " << y0 << ", \"x1\": " << x1 << ", \"y1\": " << y1
               << ", \"width\": " << w << ", \"height\": " << h << "}";
        res.set_content(js.str(), "application/json");
    });

    // POST /pdf/dpi — PDF DPI profiling (no model needed)
    svr.Post("/pdf/dpi", [&](const httplib::Request & req, httplib::Response & res) {
        auto body = req.body;
        std::string file_path;
        file_path = extract_path_field(body, "file", g_image_root, "--image-root");
        if (file_path.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"missing 'file' field\"}", "application/json");
            return;
        }
        int n_pages = 0;
        pdf_page_dpi_result * results = pdf_all_pages_dpi(file_path.c_str(), &n_pages);
        if (!results || n_pages <= 0) {
            res.status = 400;
            res.set_content("{\"error\": \"cannot read PDF\"}", "application/json");
            return;
        }
        std::ostringstream js;
        js << "{\"pages\":[";
        for (int i = 0; i < n_pages; i++) {
            if (i > 0) js << ",";
            js << "{\"page\":" << i << ",\"dpi\":" << results[i].dpi << ",\"dpi_min\":" << results[i].dpi_min
               << ",\"dpi_max\":" << results[i].dpi_max << ",\"n_images\":" << results[i].n_images
               << ",\"page_width_pt\":" << results[i].page_width_pt
               << ",\"page_height_pt\":" << results[i].page_height_pt << "}";
        }
        js << "]}";
        pdf_dpi_free(results);
        res.set_content(js.str(), "application/json");
    });

    // POST /preprocess/skew — find skew angle (no model needed)
    svr.Post("/preprocess/skew", [&](const httplib::Request & req, httplib::Response & res) {
        auto body = req.body;
        std::string image_path;
        image_path = extract_image_path(body);
        if (image_path.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"missing 'image' field\"}", "application/json");
            return;
        }
        int w, h, ch;
        unsigned char * data = stbi_load(image_path.c_str(), &w, &h, &ch, 1);
        if (!data) {
            res.status = 400;
            res.set_content("{\"error\": \"cannot load image\"}", "application/json");
            return;
        }
        float angle = 0, conf = 0;
        crispembed_find_skew(data, w, h, &angle, &conf);
        stbi_image_free(data);
        char buf[128];
        snprintf(buf, sizeof(buf), "{\"angle\":%.3f,\"confidence\":%.3f}", angle, conf);
        res.set_content(buf, "application/json");
    });

    // POST /preprocess/orientation — model-free four-way page orientation.
    // Detection is advisory: callers decide whether and how to rotate pages.
    svr.Post("/preprocess/orientation", [&](const httplib::Request & req, httplib::Response & res) {
        auto body = req.body;
        std::string image_path;
        image_path = extract_image_path(body);
        if (image_path.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"missing 'image' field\"}", "application/json");
            return;
        }
        int w = 0, h = 0, ch = 0;
        unsigned char * data = stbi_load(image_path.c_str(), &w, &h, &ch, 1);
        if (!data) {
            res.status = 400;
            res.set_content("{\"error\": \"cannot load image\"}", "application/json");
            return;
        }
        float confidence = 0.0f;
        const int angle = crispembed_detect_page_orientation(data, w, h, &confidence);
        stbi_image_free(data);
        char buf[160];
        snprintf(buf, sizeof(buf), "{\"angle\":%d,\"confidence\":%.3f,\"rotated\":false}", angle, confidence);
        res.set_content(buf, "application/json");
    });

    // POST /preprocess/dewarp — straighten curved text (no model needed)
    // Request:  {"image": "/path/to/scan.png", "output": "/path/to/out.pgm"}
    //   - "output" is optional; if present, writes dewarped PGM to that path
    // Response: JSON metadata + optionally raw PGM image bytes
    //   - If Accept: image/* → returns PGM binary directly
    //   - Otherwise → JSON {"dewarped":bool, "width":W, "height":H}
    svr.Post("/preprocess/dewarp", [&](const httplib::Request & req, httplib::Response & res) {
        auto body = req.body;
        std::string image_path, output_path;
        image_path = extract_image_path(body);
        // A client-supplied WRITE target. Confined to --image-root: without it,
        // any file this process can write is creatable or truncatable.
        output_path = extract_path_field(body, "output", g_image_root, "--image-root");
        if (image_path.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"missing 'image' field\"}", "application/json");
            return;
        }
        int w, h, ch;
        unsigned char * data = stbi_load(image_path.c_str(), &w, &h, &ch, 1);
        if (!data) {
            res.status = 400;
            res.set_content("{\"error\": \"cannot load image\"}", "application/json");
            return;
        }
        std::vector<uint8_t> out(w * h);
        int ow = 0, oh = 0;
        int ret = crispembed_dewarp(data, w, h, out.data(), &ow, &oh);
        stbi_image_free(data);
        if (ret != 0) {
            res.set_content("{\"dewarped\":false,\"reason\":\"too few textlines\"}", "application/json");
            return;
        }
        // Write to output file if requested
        if (!output_path.empty()) {
            FILE * f = fopen(output_path.c_str(), "wb");
            if (f) {
                core_imgout::emit(f, out.data(), ow, oh, 1, "dewarp");
                fclose(f);
            }
        }
        // Return image or JSON based on Accept header
        bool want_image = false;
        if (req.has_header("Accept")) {
            auto accept = req.get_header_value("Accept");
            want_image = accept.find("image/") != std::string::npos;
        }
        if (want_image) {
            // PNG (with provenance) by default; raw PGM under
            // CRISPEMBED_IMAGE_FORMAT=ppm. The MIME comes back from the same
            // call that produced the bytes, so the two cannot disagree.
            std::string body, mime;
            core_imgout::emit_to_string(body, mime, out.data(), ow, oh, 1, "dewarp");
            res.set_content(body, mime);
        } else {
            char buf[256];
            snprintf(buf, sizeof(buf), "{\"dewarped\":true,\"width\":%d,\"height\":%d,\"output\":\"%s\"}", ow, oh,
                     output_path.empty() ? "" : output_path.c_str());
            res.set_content(buf, "application/json");
        }
    });

    // POST /preprocess/tps-dewarp — TPS-based dewarp (learned localizer model)
    svr.Post("/preprocess/tps-dewarp", [&](const httplib::Request & req, httplib::Response & res) {
        auto body = req.body;
        std::string image_path, model_path;
        image_path = extract_image_path(body);
        // A GGUF is a graph this process then executes, so a client-supplied
        // model path is a code-execution surface, not a data one. Separate root
        // from --image-root: a model legitimately lives outside an image dir.
        model_path = extract_path_field(body, "model", g_model_root, "--model-root");
        if (image_path.empty() || model_path.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"missing 'image' or 'model' field\"}", "application/json");
            return;
        }
        int w, h, ch;
        unsigned char * data = stbi_load(image_path.c_str(), &w, &h, &ch, 1);
        if (!data) {
            res.status = 400;
            res.set_content("{\"error\": \"cannot load image\"}", "application/json");
            return;
        }
        std::vector<uint8_t> out(w * h);
        int ret = crispembed_tps_auto_dewarp(data, w, h, model_path.c_str(), out.data());
        stbi_image_free(data);
        if (ret != 0) {
            res.set_content("{\"dewarped\":false,\"reason\":\"tps-dewarp failed\"}", "application/json");
            return;
        }
        char buf[128];
        snprintf(buf, sizeof(buf), "{\"dewarped\":true,\"width\":%d,\"height\":%d}", w, h);
        res.set_content(buf, "application/json");
    });

    // POST /preprocess/cc-detect — model-free text line detection
    svr.Post("/preprocess/cc-detect", [&](const httplib::Request & req, httplib::Response & res) {
        auto body = req.body;
        std::string image_path;
        image_path = extract_image_path(body);
        if (image_path.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"missing 'image' field\"}", "application/json");
            return;
        }
        int w, h, ch;
        unsigned char * data = stbi_load(image_path.c_str(), &w, &h, &ch, 1);
        if (!data) {
            res.status = 400;
            res.set_content("{\"error\": \"cannot load image\"}", "application/json");
            return;
        }
        int n = 0;
        crispembed_ocr_result * regions = crispembed_cc_detect(data, w, h, &n);
        stbi_image_free(data);
        std::ostringstream js;
        js << "{\"n\":" << n << ",\"regions\":[";
        for (int i = 0; i < n; i++) {
            if (i > 0) js << ",";
            js << "{\"x\":" << regions[i].x << ",\"y\":" << regions[i].y << ",\"w\":" << regions[i].w
               << ",\"h\":" << regions[i].h << "}";
        }
        js << "]}";
        if (regions) free(regions);
        res.set_content(js.str(), "application/json");
    });

    // POST /render/ocr — render OCR results to hOCR/ALTO/PDF
    // Request: {"results": [{"text":"Hello","x":10,"y":20,"w":50,"h":15,"confidence":0.99},...],
    //           "page_width": 800, "page_height": 600, "format": "hocr"}
    // Response: rendered document (hOCR XHTML, ALTO XML, or PDF binary)
    svr.Post("/render/ocr", [&](const httplib::Request & req, httplib::Response & res) {
        auto body = req.body;

        // Parse format
        std::string format = "text";
        {
            std::vector<std::string> vals;
            if (json_extract_strings(body, "format", vals) > 0) format = vals[0];
        }

        // Parse page dimensions
        int page_w = 800, page_h = 600;
        page_w = (int)json_extract_number(body, "page_width", page_w);
        page_h = (int)json_extract_number(body, "page_height", page_h);

        // Parse results array (minimal JSON — extract text + bbox per entry)
        // Each result: {"text":"...","x":N,"y":N,"w":N,"h":N,"confidence":F}
        std::vector<crispembed_ocr_result> results;
        std::vector<std::string> texts; // keep text alive
        auto rpos = core_json::json_find_key_value(body, "results");
        if (rpos != std::string::npos && body[rpos] == '[') {
            auto arr_start = rpos;
            auto arr_end = body.rfind(']');
            if (arr_start != std::string::npos && arr_end != std::string::npos) {
                std::string arr = body.substr(arr_start, arr_end - arr_start + 1);
                // Parse each {...} object
                size_t p = 0;
                while ((p = arr.find('{', p)) != std::string::npos) {
                    auto e = arr.find('}', p);
                    if (e == std::string::npos) break;
                    std::string obj = arr.substr(p, e - p + 1);
                    p = e + 1;

                    crispembed_ocr_result r = {};
                    // Extract text (escape-aware, depth-1 within this object)
                    {
                        std::vector<std::string> vals;
                        json_extract_strings(obj, "text", vals);
                        texts.push_back(vals.empty() ? "" : vals[0]);
                    }
                    r.text = texts.back().c_str();
                    r.text_len = (int)texts.back().size();
                    // Extract numbers (per-object; decoy-safe depth-1 finder)
                    auto parse_num = [&](const char * key) -> float {
                        return (float)json_extract_number(obj, key, 0.0);
                    };
                    r.x = parse_num("x");
                    r.y = parse_num("y");
                    r.w = parse_num("w");
                    r.h = parse_num("h");
                    r.confidence = parse_num("confidence");
                    if (r.confidence == 0) r.confidence = 1.0f;
                    results.push_back(r);
                }
            }
        }

        if (results.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"no results to render\"}", "application/json");
            return;
        }

        char * rendered = crispembed_ocr_render(results.data(), (int)results.size(), page_w, page_h, format.c_str());
        if (!rendered) {
            res.status = 500;
            res.set_content("{\"error\": \"rendering failed\"}", "application/json");
            return;
        }

        // Set content type based on format
        const char * content_type = "text/plain";
        if (format == "hocr")
            content_type = "text/html; charset=utf-8";
        else if (format == "alto")
            content_type = "application/xml; charset=utf-8";
        else if (format == "pdf")
            content_type = "application/pdf";

        res.set_content(rendered, content_type);
        free(rendered);
    });

    // POST /text/sr — text image super-resolution (upscale low-DPI text before OCR)
    svr.Post("/text/sr", [&](const httplib::Request & req, httplib::Response & res) {
        if (!text_sr_ctx) {
            res.status = 503;
            res.set_content("{\"error\": \"no text SR model loaded (use --sr-model)\"}", "application/json");
            return;
        }

        auto body = req.body;
        std::string image_path;
        image_path = extract_image_path(body);
        if (image_path.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"missing 'image' field\"}", "application/json");
            return;
        }

        int w, h, ch;
        unsigned char * data = stbi_load(image_path.c_str(), &w, &h, &ch, 3);
        if (!data) {
            res.status = 400;
            res.set_content("{\"error\": \"cannot load image\"}", "application/json");
            return;
        }

        std::lock_guard<std::mutex> lock(text_sr_mutex);
        auto t0 = std::chrono::steady_clock::now();

        uint8_t * out = nullptr;
        int ow = 0, oh = 0;
        int rc = crispembed_text_sr_process(text_sr_ctx, data, w, h,
                                            /*tile_size=*/0, /*tile_overlap=*/0, &out, &ow, &oh);
        stbi_image_free(data);

        auto t1 = std::chrono::steady_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        if (rc != 0 || !out) {
            res.status = 500;
            res.set_content("{\"error\": \"text SR processing failed\"}", "application/json");
            return;
        }

        // Base64-encode the raw RGB output
        static const char b64chars[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        const size_t n_bytes = (size_t)ow * oh * 3;
        std::string img_format;
        const std::string b64 = encode_image_b64(out, ow, oh, 3, "text-sr", img_format);
        crispembed_text_sr_free_image(out);

        const int scale = crispembed_text_sr_upscale_factor(text_sr_ctx);

        std::ostringstream js;
        js << "{\"image\": \"" << b64 << "\", \"format\": \"" << img_format << "\"" << ", \"width\": " << ow
           << ", \"height\": " << oh << ", \"original_width\": " << w << ", \"original_height\": " << h
           << ", \"upscale_factor\": " << scale << ", \"ms\": " << std::fixed << std::setprecision(1) << ms << "}";

        fprintf(stderr, "crispembed-server: /text/sr in %.1f ms (%dx%d -> %dx%d, %dx)\n", ms, w, h, ow, oh, scale);
        res.set_content(js.str(), "application/json");
    });

    // POST /pan/sr — PAN whole-image super-resolution (Pixel Attention Network)
    svr.Post("/pan/sr", [&](const httplib::Request & req, httplib::Response & res) {
        if (!pan_sr_ctx) {
            res.status = 503;
            res.set_content("{\"error\": \"no PAN SR model loaded (use --pan-model)\"}", "application/json");
            return;
        }

        auto body = req.body;
        std::string image_path;
        image_path = extract_image_path(body);
        if (image_path.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"missing 'image' field\"}", "application/json");
            return;
        }

        int w, h, ch;
        unsigned char * data = stbi_load(image_path.c_str(), &w, &h, &ch, 3);
        if (!data) {
            res.status = 400;
            res.set_content("{\"error\": \"cannot load image\"}", "application/json");
            return;
        }

        std::lock_guard<std::mutex> lock(pan_sr_mutex);
        auto t0 = std::chrono::steady_clock::now();

        uint8_t * out = nullptr;
        int ow = 0, oh = 0;
        int rc = crispembed_pan_sr_process(pan_sr_ctx, data, w, h,
                                           /*tile_size=*/0, /*tile_overlap=*/0, &out, &ow, &oh);
        stbi_image_free(data);

        auto t1 = std::chrono::steady_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        if (rc != 0 || !out) {
            res.status = 500;
            res.set_content("{\"error\": \"PAN SR processing failed\"}", "application/json");
            return;
        }

        // Base64-encode the raw RGB output
        static const char b64chars[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        const size_t n_bytes = (size_t)ow * oh * 3;
        std::string img_format;
        const std::string b64 = encode_image_b64(out, ow, oh, 3, "pan-sr", img_format);
        crispembed_pan_sr_free_image(out);

        const int scale = crispembed_pan_sr_scale(pan_sr_ctx);

        std::ostringstream js;
        js << "{\"image\": \"" << b64 << "\", \"format\": \"" << img_format << "\"" << ", \"width\": " << ow
           << ", \"height\": " << oh << ", \"original_width\": " << w << ", \"original_height\": " << h
           << ", \"upscale_factor\": " << scale << ", \"ms\": " << std::fixed << std::setprecision(1) << ms << "}";

        fprintf(stderr, "crispembed-server: /pan/sr in %.1f ms (%dx%d -> %dx%d, %dx)\n", ms, w, h, ow, oh, scale);
        res.set_content(js.str(), "application/json");
    });

    // POST /sam2/segment — SAM 2.1 masks for point/box prompts.
    // {"image": "photo.png", "points": [[x, y, label], ...], "box": [x0, y0, x1, y1], "multimask": false}
    // Points and box in image pixels; label 1 object, 0 background. Returns one mask (or SAM's three
    // alternatives with "multimask": true) as images (0/255) with their predicted IoU.
    svr.Post("/sam2/segment", [&](const httplib::Request & req, httplib::Response & res) {
        if (!sam2_ctx) {
            res.status = 503;
            res.set_content("{\"error\": \"no SAM 2 model loaded (use --sam2-model)\"}", "application/json");
            return;
        }
        const std::string image_path = extract_image_path(req.body);
        std::vector<double> flat_points, flat_box;
        core_json::json_extract_numbers(req.body, "points", flat_points);
        core_json::json_extract_numbers(req.body, "box", flat_box);
        const bool multimask = core_json::json_extract_bool(req.body, "multimask", false);
        if (image_path.empty() || flat_points.size() % 3 != 0 || (flat_box.size() != 0 && flat_box.size() != 4) ||
            (flat_points.empty() && flat_box.empty())) {
            res.status = 400;
            res.set_content(
                "{\"error\": \"need 'image' and 'points' ([[x, y, label], ...]) and/or 'box' ([x0, y0, x1, y1])\"}",
                "application/json");
            return;
        }
        std::vector<float> points;
        std::vector<int> labels;
        for (size_t i = 0; i < flat_points.size(); i += 3) {
            points.push_back((float)flat_points[i]);
            points.push_back((float)flat_points[i + 1]);
            labels.push_back((int)flat_points[i + 2]);
        }
        const std::vector<float> box(flat_box.begin(), flat_box.end());
        int w, h, ch;
        unsigned char * data = stbi_load(image_path.c_str(), &w, &h, &ch, 3);
        if (!data) {
            res.status = 400;
            res.set_content("{\"error\": \"cannot load image\"}", "application/json");
            return;
        }
        std::lock_guard<std::mutex> lock(sam2_mutex);
        auto t0 = std::chrono::steady_clock::now();
        uint8_t * masks = nullptr;
        float scores[3] = { 0, 0, 0 };
        int count = 0;
        const int rc =
            crispembed_sam2_process(sam2_ctx, data, w, h, points.data(), labels.data(), (int)labels.size(),
                                    box.empty() ? nullptr : box.data(), multimask ? 1 : 0, &masks, scores, &count);
        stbi_image_free(data);
        const double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
        if (rc != 0 || !masks) {
            res.status = 500;
            res.set_content("{\"error\": \"SAM 2 segmentation failed\"}", "application/json");
            return;
        }
        std::ostringstream js;
        js << "{\"masks\": [";
        for (int i = 0; i < count; i++) {
            std::string img_format;
            const std::string b64 = encode_image_b64(masks + (size_t)i * w * h, w, h, 1, "sam2", img_format);
            js << (i ? ", " : "") << "{\"image\": \"" << b64 << "\", \"format\": \"" << img_format
               << "\", \"score\": " << std::fixed << std::setprecision(4) << scores[i] << "}";
        }
        crispembed_sam2_free_masks(masks);
        js << "], \"width\": " << w << ", \"height\": " << h << ", \"ms\": " << std::fixed << std::setprecision(1) << ms
           << "}";
        fprintf(stderr, "crispembed-server: /sam2/segment in %.1f ms (%dx%d, %d masks)\n", ms, w, h, count);
        res.set_content(js.str(), "application/json");
    });

    // POST /hat/sr — HAT whole-image super-resolution (Hybrid Attention Transformer)
    svr.Post("/hat/sr", [&](const httplib::Request & req, httplib::Response & res) {
        if (!hat_sr_ctx) {
            res.status = 503;
            res.set_content("{\"error\": \"no HAT SR model loaded (use --hat-model)\"}", "application/json");
            return;
        }

        auto body = req.body;
        std::string image_path;
        image_path = extract_image_path(body);
        if (image_path.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"missing 'image' field\"}", "application/json");
            return;
        }

        int w, h, ch;
        unsigned char * data = stbi_load(image_path.c_str(), &w, &h, &ch, 3);
        if (!data) {
            res.status = 400;
            res.set_content("{\"error\": \"cannot load image\"}", "application/json");
            return;
        }

        std::lock_guard<std::mutex> lock(hat_sr_mutex);
        auto t0 = std::chrono::steady_clock::now();

        uint8_t * out = nullptr;
        int ow = 0, oh = 0;
        int rc = crispembed_hat_sr_process(hat_sr_ctx, data, w, h,
                                           /*tile_size=*/0, /*tile_overlap=*/0, &out, &ow, &oh);
        stbi_image_free(data);

        auto t1 = std::chrono::steady_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        if (rc != 0 || !out) {
            res.status = 500;
            res.set_content("{\"error\": \"HAT SR processing failed\"}", "application/json");
            return;
        }

        static const char b64chars[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        const size_t n_bytes = (size_t)ow * oh * 3;
        std::string img_format;
        const std::string b64 = encode_image_b64(out, ow, oh, 3, "hat-sr", img_format);
        crispembed_hat_sr_free_image(out);

        const int scale = crispembed_hat_sr_scale(hat_sr_ctx);

        std::ostringstream js;
        js << "{\"image\": \"" << b64 << "\", \"format\": \"" << img_format << "\"" << ", \"width\": " << ow
           << ", \"height\": " << oh << ", \"original_width\": " << w << ", \"original_height\": " << h
           << ", \"upscale_factor\": " << scale << ", \"ms\": " << std::fixed << std::setprecision(1) << ms << "}";

        fprintf(stderr, "crispembed-server: /hat/sr in %.1f ms (%dx%d -> %dx%d, %dx)\n", ms, w, h, ow, oh, scale);
        res.set_content(js.str(), "application/json");
    });

    // POST /dat/sr — DAT whole-image super-resolution (Dual Aggregation Transformer)
    svr.Post("/dat/sr", [&](const httplib::Request & req, httplib::Response & res) {
        if (!dat_sr_ctx) {
            res.status = 503;
            res.set_content("{\"error\": \"no DAT SR model loaded (use --dat-model)\"}", "application/json");
            return;
        }

        auto body = req.body;
        std::string image_path;
        image_path = extract_image_path(body);
        if (image_path.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"missing 'image' field\"}", "application/json");
            return;
        }

        int w, h, ch;
        unsigned char * data = stbi_load(image_path.c_str(), &w, &h, &ch, 3);
        if (!data) {
            res.status = 400;
            res.set_content("{\"error\": \"cannot load image\"}", "application/json");
            return;
        }

        std::lock_guard<std::mutex> lock(dat_sr_mutex);
        auto t0 = std::chrono::steady_clock::now();

        uint8_t * out = nullptr;
        int ow = 0, oh = 0;
        int rc = crispembed_dat_sr_process(dat_sr_ctx, data, w, h,
                                           /*tile_size=*/0, /*tile_overlap=*/0, &out, &ow, &oh);
        stbi_image_free(data);

        auto t1 = std::chrono::steady_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        if (rc != 0 || !out) {
            res.status = 500;
            res.set_content("{\"error\": \"DAT SR processing failed\"}", "application/json");
            return;
        }

        static const char b64chars[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        const size_t n_bytes = (size_t)ow * oh * 3;
        std::string img_format;
        const std::string b64 = encode_image_b64(out, ow, oh, 3, "dat-sr", img_format);
        crispembed_dat_sr_free_image(out);

        const int scale = (w > 0) ? ow / w : 2;

        std::ostringstream js;
        js << "{\"image\": \"" << b64 << "\", \"format\": \"" << img_format << "\"" << ", \"width\": " << ow
           << ", \"height\": " << oh << ", \"original_width\": " << w << ", \"original_height\": " << h
           << ", \"upscale_factor\": " << scale << ", \"ms\": " << std::fixed << std::setprecision(1) << ms << "}";

        fprintf(stderr, "crispembed-server: /dat/sr in %.1f ms (%dx%d -> %dx%d, %dx)\n", ms, w, h, ow, oh, scale);
        res.set_content(js.str(), "application/json");
    });

    // POST /safmn/sr — SAFMN whole-image super-resolution
    svr.Post("/safmn/sr", [&](const httplib::Request & req, httplib::Response & res) {
        if (!safmn_sr_ctx) {
            res.status = 503;
            res.set_content("{\"error\": \"no SAFMN SR model loaded (use --safmn-model)\"}", "application/json");
            return;
        }

        auto body = req.body;
        std::string image_path;
        image_path = extract_image_path(body);
        if (image_path.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"missing 'image' field\"}", "application/json");
            return;
        }

        int w, h, ch;
        unsigned char * data = stbi_load(image_path.c_str(), &w, &h, &ch, 3);
        if (!data) {
            res.status = 400;
            res.set_content("{\"error\": \"cannot load image\"}", "application/json");
            return;
        }

        std::lock_guard<std::mutex> lock(safmn_sr_mutex);
        auto t0 = std::chrono::steady_clock::now();

        uint8_t * out = nullptr;
        int ow = 0, oh = 0;
        int rc = crispembed_safmn_sr_process(safmn_sr_ctx, data, w, h,
                                             /*tile_size=*/0, /*tile_overlap=*/0, &out, &ow, &oh);
        stbi_image_free(data);

        auto t1 = std::chrono::steady_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        if (rc != 0 || !out) {
            res.status = 500;
            res.set_content("{\"error\": \"SAFMN SR processing failed\"}", "application/json");
            return;
        }

        static const char b64chars[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        const size_t n_bytes = (size_t)ow * oh * 3;
        std::string img_format;
        const std::string b64 = encode_image_b64(out, ow, oh, 3, "safmn-sr", img_format);
        crispembed_safmn_sr_free_image(out);

        const int scale = crispembed_safmn_sr_scale(safmn_sr_ctx);

        std::ostringstream js;
        js << "{\"image\": \"" << b64 << "\", \"format\": \"" << img_format << "\"" << ", \"width\": " << ow
           << ", \"height\": " << oh << ", \"original_width\": " << w << ", \"original_height\": " << h
           << ", \"upscale_factor\": " << scale << ", \"ms\": " << std::fixed << std::setprecision(1) << ms << "}";

        fprintf(stderr, "crispembed-server: /safmn/sr in %.1f ms (%dx%d -> %dx%d, %dx)\n", ms, w, h, ow, oh, scale);
        res.set_content(js.str(), "application/json");
    });

    // POST /esrgan/sr — Real-ESRGAN whole-image super-resolution
    svr.Post("/esrgan/sr", [&](const httplib::Request & req, httplib::Response & res) {
        if (!esrgan_sr_ctx) {
            res.status = 503;
            res.set_content("{\"error\": \"no Real-ESRGAN SR model loaded (use --esrgan-model)\"}", "application/json");
            return;
        }

        auto body = req.body;
        std::string image_path;
        image_path = extract_image_path(body);
        if (image_path.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"missing 'image' field\"}", "application/json");
            return;
        }

        int w, h, ch;
        unsigned char * data = stbi_load(image_path.c_str(), &w, &h, &ch, 3);
        if (!data) {
            res.status = 400;
            res.set_content("{\"error\": \"cannot load image\"}", "application/json");
            return;
        }

        std::lock_guard<std::mutex> lock(esrgan_sr_mutex);
        auto t0 = std::chrono::steady_clock::now();

        uint8_t * out = nullptr;
        int ow = 0, oh = 0;
        int rc = crispembed_esrgan_sr_process(esrgan_sr_ctx, data, w, h,
                                              /*tile_size=*/0, /*tile_overlap=*/0, &out, &ow, &oh);
        stbi_image_free(data);

        auto t1 = std::chrono::steady_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        if (rc != 0 || !out) {
            res.status = 500;
            res.set_content("{\"error\": \"Real-ESRGAN SR processing failed\"}", "application/json");
            return;
        }

        static const char b64chars[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        const size_t n_bytes = (size_t)ow * oh * 3;
        std::string img_format;
        const std::string b64 = encode_image_b64(out, ow, oh, 3, "esrgan-sr", img_format);
        crispembed_esrgan_sr_free_image(out);

        const int scale = crispembed_esrgan_sr_scale(esrgan_sr_ctx);

        std::ostringstream js;
        js << "{\"image\": \"" << b64 << "\", \"format\": \"" << img_format << "\"" << ", \"width\": " << ow
           << ", \"height\": " << oh << ", \"original_width\": " << w << ", \"original_height\": " << h
           << ", \"upscale_factor\": " << scale << ", \"ms\": " << std::fixed << std::setprecision(1) << ms << "}";

        fprintf(stderr, "crispembed-server: /esrgan/sr in %.1f ms (%dx%d -> %dx%d, %dx)\n", ms, w, h, ow, oh, scale);
        res.set_content(js.str(), "application/json");
    });

    // POST /swinir/sr — SwinIR-light whole-image super-resolution
    svr.Post("/swinir/sr", [&](const httplib::Request & req, httplib::Response & res) {
        if (!swinir_sr_ctx) {
            res.status = 503;
            res.set_content("{\"error\": \"no SwinIR SR model loaded (use --swinir-model)\"}", "application/json");
            return;
        }

        auto body = req.body;
        std::string image_path;
        image_path = extract_image_path(body);
        if (image_path.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"missing 'image' field\"}", "application/json");
            return;
        }

        int w, h, ch;
        unsigned char * data = stbi_load(image_path.c_str(), &w, &h, &ch, 3);
        if (!data) {
            res.status = 400;
            res.set_content("{\"error\": \"cannot load image\"}", "application/json");
            return;
        }

        std::lock_guard<std::mutex> lock(swinir_sr_mutex);
        auto t0 = std::chrono::steady_clock::now();

        uint8_t * out = nullptr;
        int ow = 0, oh = 0;
        int rc = crispembed_swinir_sr_process(swinir_sr_ctx, data, w, h,
                                              /*tile_size=*/0, /*tile_overlap=*/0, &out, &ow, &oh);
        stbi_image_free(data);

        auto t1 = std::chrono::steady_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        if (rc != 0 || !out) {
            res.status = 500;
            res.set_content("{\"error\": \"SwinIR SR processing failed\"}", "application/json");
            return;
        }

        // Base64-encode the raw RGB output
        static const char b64chars[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        const size_t n_bytes = (size_t)ow * oh * 3;
        std::string img_format;
        const std::string b64 = encode_image_b64(out, ow, oh, 3, "swinir-sr", img_format);
        crispembed_swinir_sr_free_image(out);

        const int scale = crispembed_swinir_sr_scale(swinir_sr_ctx);

        std::ostringstream js;
        js << "{\"image\": \"" << b64 << "\", \"format\": \"" << img_format << "\"" << ", \"width\": " << ow
           << ", \"height\": " << oh << ", \"original_width\": " << w << ", \"original_height\": " << h
           << ", \"upscale_factor\": " << scale << ", \"ms\": " << std::fixed << std::setprecision(1) << ms << "}";

        fprintf(stderr, "crispembed-server: /swinir/sr in %.1f ms (%dx%d -> %dx%d, %dx)\n", ms, w, h, ow, oh, scale);
        res.set_content(js.str(), "application/json");
    });

    // POST /tbsrn/sr — TBSRN text-line super-resolution (Telescope)
    svr.Post("/tbsrn/sr", [&](const httplib::Request & req, httplib::Response & res) {
        if (!tbsrn_sr_ctx) {
            res.status = 503;
            res.set_content("{\"error\": \"no TBSRN SR model loaded (use --tbsrn-model)\"}", "application/json");
            return;
        }

        auto body = req.body;
        std::string image_path;
        image_path = extract_image_path(body);
        if (image_path.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"missing 'image' field\"}", "application/json");
            return;
        }

        int w, h, ch;
        unsigned char * data = stbi_load(image_path.c_str(), &w, &h, &ch, 3);
        if (!data) {
            res.status = 400;
            res.set_content("{\"error\": \"cannot load image\"}", "application/json");
            return;
        }

        std::lock_guard<std::mutex> lock(tbsrn_sr_mutex);
        auto t0 = std::chrono::steady_clock::now();

        uint8_t * out = nullptr;
        int ow = 0, oh = 0;
        int rc = crispembed_tbsrn_sr_process(tbsrn_sr_ctx, data, w, h, &out, &ow, &oh);
        stbi_image_free(data);

        auto t1 = std::chrono::steady_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        if (rc != 0 || !out) {
            res.status = 500;
            res.set_content("{\"error\": \"TBSRN SR processing failed\"}", "application/json");
            return;
        }

        // Base64-encode the raw RGB output
        static const char b64chars[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        const size_t n_bytes = (size_t)ow * oh * 3;
        std::string img_format;
        const std::string b64 = encode_image_b64(out, ow, oh, 3, "tbsrn-sr", img_format);
        crispembed_tbsrn_sr_free_image(out);

        std::ostringstream js;
        js << "{\"image\": \"" << b64 << "\", \"format\": \"" << img_format << "\"" << ", \"width\": " << ow
           << ", \"height\": " << oh << ", \"original_width\": " << w << ", \"original_height\": " << h
           << ", \"upscale_factor\": 4" << ", \"ms\": " << std::fixed << std::setprecision(1) << ms << "}";

        fprintf(stderr, "crispembed-server: /tbsrn/sr in %.1f ms (%dx%d -> %dx%d, 4x)\n", ms, w, h, ow, oh);
        res.set_content(js.str(), "application/json");
    });

    // POST /restormer — Restormer image restoration (denoising, deblurring, deraining)
    svr.Post("/restormer", [&](const httplib::Request & req, httplib::Response & res) {
        if (!restormer_ctx) {
            res.status = 503;
            res.set_content("{\"error\": \"no Restormer model loaded (use --restormer-model)\"}", "application/json");
            return;
        }

        auto body = req.body;
        std::string image_path;
        image_path = extract_image_path(body);
        if (image_path.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"missing 'image' field\"}", "application/json");
            return;
        }

        int w, h, ch;
        unsigned char * data = stbi_load(image_path.c_str(), &w, &h, &ch, 3);
        if (!data) {
            res.status = 400;
            res.set_content("{\"error\": \"cannot load image\"}", "application/json");
            return;
        }

        std::lock_guard<std::mutex> lock(restormer_mutex);
        auto t0 = std::chrono::steady_clock::now();

        uint8_t * out = nullptr;
        int rc = crispembed_restormer_process(restormer_ctx, data, w, h,
                                              /*tile_size=*/0, /*tile_overlap=*/0, &out);
        stbi_image_free(data);

        auto t1 = std::chrono::steady_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        if (rc != 0 || !out) {
            res.status = 500;
            res.set_content("{\"error\": \"Restormer processing failed\"}", "application/json");
            return;
        }

        // Base64-encode the raw RGB output
        static const char b64chars[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        const size_t n_bytes = (size_t)w * h * 3;
        std::string img_format;
        const std::string b64 = encode_image_b64(out, w, h, 3, "restormer", img_format);
        crispembed_restormer_free_image(out);

        std::ostringstream js;
        js << "{\"image\": \"" << b64 << "\", \"format\": \"" << img_format << "\"" << ", \"width\": " << w
           << ", \"height\": " << h << ", \"ms\": " << std::fixed << std::setprecision(1) << ms << "}";

        fprintf(stderr, "crispembed-server: /restormer in %.1f ms (%dx%d)\n", ms, w, h);
        res.set_content(js.str(), "application/json");
    });

    // POST /scunet/denoise — SCUNet image denoising (Swin-Conv-UNet)
    svr.Post("/scunet/denoise", [&](const httplib::Request & req, httplib::Response & res) {
        if (!scunet_ctx) {
            res.status = 503;
            res.set_content("{\"error\": \"no SCUNet model loaded (use --scunet-model)\"}", "application/json");
            return;
        }

        auto body = req.body;
        std::string image_path;
        image_path = extract_image_path(body);
        if (image_path.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"missing 'image' field\"}", "application/json");
            return;
        }

        int w, h, ch;
        unsigned char * data = stbi_load(image_path.c_str(), &w, &h, &ch, 3);
        if (!data) {
            res.status = 400;
            res.set_content("{\"error\": \"cannot load image\"}", "application/json");
            return;
        }

        std::lock_guard<std::mutex> lock(scunet_mutex);
        auto t0 = std::chrono::steady_clock::now();

        uint8_t * out = nullptr;
        int rc = crispembed_scunet_process(scunet_ctx, data, w, h, &out);
        stbi_image_free(data);

        auto t1 = std::chrono::steady_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        if (rc != 0 || !out) {
            res.status = 500;
            res.set_content("{\"error\": \"SCUNet denoising failed\"}", "application/json");
            return;
        }

        // Base64-encode the raw RGB output
        static const char b64chars[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        const size_t n_bytes = (size_t)w * h * 3;
        std::string img_format;
        const std::string b64 = encode_image_b64(out, w, h, 3, "scunet", img_format);
        crispembed_scunet_free_image(out);

        std::ostringstream js;
        js << "{\"image\": \"" << b64 << "\", \"format\": \"" << img_format << "\"" << ", \"width\": " << w
           << ", \"height\": " << h << ", \"ms\": " << std::fixed << std::setprecision(1) << ms << "}";

        fprintf(stderr, "crispembed-server: /scunet/denoise in %.1f ms (%dx%d)\n", ms, w, h);
        res.set_content(js.str(), "application/json");
    });

    // POST /instructir/restore — InstructIR all-in-one image restoration
    svr.Post("/instructir/restore", [&](const httplib::Request & req, httplib::Response & res) {
        if (!instructir_ctx) {
            res.status = 503;
            res.set_content("{\"error\": \"no InstructIR model loaded (use --instructir-model)\"}", "application/json");
            return;
        }

        auto body = req.body;
        std::string image_path;
        image_path = extract_image_path(body);
        if (image_path.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"missing 'image' field\"}", "application/json");
            return;
        }

        // Parse task (default 0 = denoise)
        int task = 0;
        task = (int)json_extract_number(body, "task", task);
        if (task < 0 || task > 6) {
            res.status = 400;
            res.set_content("{\"error\": \"task must be 0-6\"}", "application/json");
            return;
        }

        int w, h, ch;
        unsigned char * data = stbi_load(image_path.c_str(), &w, &h, &ch, 3);
        if (!data) {
            res.status = 400;
            res.set_content("{\"error\": \"cannot load image\"}", "application/json");
            return;
        }

        std::lock_guard<std::mutex> lock(instructir_mutex);
        auto t0 = std::chrono::steady_clock::now();

        uint8_t * out = nullptr;
        int rc = crispembed_instructir_process(instructir_ctx, task, data, w, h, &out);
        stbi_image_free(data);

        auto t1 = std::chrono::steady_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        if (rc != 0 || !out) {
            res.status = 500;
            res.set_content("{\"error\": \"InstructIR processing failed\"}", "application/json");
            return;
        }

        // Base64-encode the raw RGB output
        static const char b64chars[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        const size_t n_bytes = (size_t)w * h * 3;
        std::string img_format;
        const std::string b64 = encode_image_b64(out, w, h, 3, "instructir", img_format);
        crispembed_instructir_free_image(out);

        std::ostringstream js;
        js << "{\"image\": \"" << b64 << "\", \"format\": \"" << img_format << "\"" << ", \"width\": " << w
           << ", \"height\": " << h << ", \"task\": " << task << ", \"ms\": " << std::fixed << std::setprecision(1)
           << ms << "}";

        fprintf(stderr, "crispembed-server: /instructir/restore task=%d in %.1f ms (%dx%d)\n", task, ms, w, h);
        res.set_content(js.str(), "application/json");
    });

    // POST /adair/restore — AdaIR all-in-one image restoration (Restormer+AFLB+FFT)
    svr.Post("/adair/restore", [&](const httplib::Request & req, httplib::Response & res) {
        if (!adair_ctx) {
            res.status = 503;
            res.set_content("{\"error\": \"no AdaIR model loaded (use --adair-model)\"}", "application/json");
            return;
        }

        auto body = req.body;
        std::string image_path;
        image_path = extract_image_path(body);
        if (image_path.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"missing 'image' field\"}", "application/json");
            return;
        }

        int w, h, ch;
        unsigned char * data = stbi_load(image_path.c_str(), &w, &h, &ch, 3);
        if (!data) {
            res.status = 400;
            res.set_content("{\"error\": \"cannot load image\"}", "application/json");
            return;
        }

        std::lock_guard<std::mutex> lock(adair_mutex);
        auto t0 = std::chrono::steady_clock::now();

        uint8_t * out = nullptr;
        int rc = crispembed_adair_process(adair_ctx, data, w, h, &out);
        stbi_image_free(data);

        auto t1 = std::chrono::steady_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        if (rc != 0 || !out) {
            res.status = 500;
            res.set_content("{\"error\": \"AdaIR restoration failed\"}", "application/json");
            return;
        }

        // Base64-encode the raw RGB output
        static const char b64chars[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        const size_t n_bytes = (size_t)w * h * 3;
        std::string img_format;
        const std::string b64 = encode_image_b64(out, w, h, 3, "adair", img_format);
        crispembed_adair_free_image(out);

        std::ostringstream js;
        js << "{\"image\": \"" << b64 << "\", \"format\": \"" << img_format << "\"" << ", \"width\": " << w
           << ", \"height\": " << h << ", \"ms\": " << std::fixed << std::setprecision(1) << ms << "}";

        fprintf(stderr, "crispembed-server: /adair/restore in %.1f ms (%dx%d)\n", ms, w, h);
        res.set_content(js.str(), "application/json");
    });

    // POST /ocr/document — end-to-end multi-page OCR
    // Accepts:
    //   multipart/form-data: files named "page" (or "page0","page1",...) → image bytes
    //   OR application/json: {"images": ["/path/page1.png", "/path/page2.png"],
    //                         "format": "text|hocr|alto|pdf",
    //                         "cleanup": true, "dewarp": false, "autorotate": false}
    // Returns: rendered document in the requested format
    svr.Post("/ocr/document", [&](const httplib::Request & req, httplib::Response & res) {
        std::string format = "text";
        bool do_cleanup = true;
        bool do_dewarp = false;
        bool do_autorotate = false;
        std::vector<std::string> temp_files; // track files to clean up

        // Collect page images (either from multipart or JSON paths)
        std::vector<std::string> page_paths;

        if (req.is_multipart_form_data()) {
            // Multipart upload: save each file to temp, collect paths
            auto files = req.files;
            for (auto & [name, file] : files) {
                if (name == "format") {
                    format = file.content;
                    continue;
                }
                if (name == "cleanup") {
                    do_cleanup = file.content != "false" && file.content != "0";
                    continue;
                }
                if (name == "dewarp") {
                    do_dewarp = file.content == "true" || file.content == "1";
                    continue;
                }
                if (name == "autorotate") {
                    do_autorotate = file.content == "true" || file.content == "1";
                    continue;
                }
                // Must be a page image
                const std::string tmp_path = make_private_temp_file(".img");
                if (tmp_path.empty()) continue;
                FILE * f = fopen(tmp_path.c_str(), "wb");
                if (f) {
                    fwrite(file.content.data(), 1, file.content.size(), f);
                    fclose(f);
                    page_paths.push_back(tmp_path);
                    temp_files.push_back(tmp_path);
                } else {
                    std::remove(tmp_path.c_str());
                }
            }
        } else {
            // JSON mode: parse image paths
            auto body = req.body;
            {
                std::vector<std::string> vals;
                if (json_extract_strings(body, "format", vals) > 0) format = vals[0];
            }
            auto rpos = core_json::json_find_key_value(body, "autorotate");
            if (rpos != std::string::npos) do_autorotate = body.compare(rpos, 4, "true") == 0;
            // Parse "images" array (handles both a single string and an array).
            // Each entry is a client-supplied filesystem path, so it gets the
            // same --image-root confinement as the single-image field — this
            // array was the one path-valued input that bypassed it.
            {
                std::vector<std::string> vals;
                json_extract_strings(body, "images", vals);
                for (const auto & p : vals) {
                    if (p.empty()) continue;
                    if (!path_within(p, g_image_root)) {
                        fprintf(stderr, "crispembed-server: rejected 'images' path outside --image-root (%s): %s\n",
                                g_image_root.c_str(), p.c_str());
                        continue;
                    }
                    page_paths.push_back(p);
                }
            }
            // Single image shortcut
            if (page_paths.empty()) {
                const std::string single = extract_image_path(body);
                if (!single.empty()) page_paths.push_back(single);
            }
        }

        if (page_paths.empty()) {
            res.status = 400;
            res.set_content("{\"error\": \"no page images provided\"}", "application/json");
            return;
        }

        auto t0 = std::chrono::high_resolution_clock::now();

        // Process each page
        ocr_renderer * renderer = ocr_render_create(format == "hocr"   ? OCR_RENDER_HOCR
                                                    : format == "alto" ? OCR_RENDER_ALTO
                                                    : format == "pdf"  ? OCR_RENDER_PDF
                                                                       : OCR_RENDER_TEXT);
        if (format == "pdf") ocr_render_set_pdfa(renderer, 1);
        ocr_render_begin(renderer);

        int total_regions = 0;
        for (size_t pi = 0; pi < page_paths.size(); pi++) {
            std::string page_source = page_paths[pi];
            if (do_autorotate) {
                int ow = 0, oh = 0, och = 0;
                unsigned char * gray = stbi_load(page_source.c_str(), &ow, &oh, &och, 1);
                float orientation_confidence = 0.0f;
                const int angle = gray ? crispembed_detect_page_orientation(gray, ow, oh, &orientation_confidence) : 0;
                if (gray) stbi_image_free(gray);
                if (angle != 0 && orientation_confidence >= 0.55f) {
                    int rw = 0, rh = 0, rc = 0;
                    unsigned char * rgb = stbi_load(page_source.c_str(), &rw, &rh, &rc, 3);
                    // Pre-created 0600 and owned by us, so the rewrite below
                    // cannot be redirected through a planted symlink.
                    const std::string rotated_path = make_private_temp_file(".ppm");
                    if (rgb && !rotated_path.empty() && write_rotated_ppm(rotated_path.c_str(), rgb, rw, rh, angle)) {
                        page_source = rotated_path;
                        temp_files.push_back(page_source);
                    } else if (!rotated_path.empty()) {
                        std::remove(rotated_path.c_str());
                    }
                    if (rgb) stbi_image_free(rgb);
                }
            }
            int w = 0, h = 0, ch = 0;
            unsigned char * img = stbi_load(page_source.c_str(), &w, &h, &ch, 0);
            if (!img) continue;

            // Optional dewarp (grayscale)
            std::vector<uint8_t> gray_buf;
            if (do_dewarp && ch >= 1) {
                // Convert to gray if needed
                std::vector<uint8_t> gray(w * h);
                if (ch == 1) {
                    memcpy(gray.data(), img, w * h);
                } else {
                    for (int i = 0; i < w * h; i++)
                        gray[i] = (uint8_t)((img[i * ch] * 77 + img[i * ch + 1] * 150 + img[i * ch + 2] * 29) >> 8);
                }
                std::vector<uint8_t> dewarped(w * h);
                int dw = 0, dh = 0;
                if (crispembed_dewarp(gray.data(), w, h, dewarped.data(), &dw, &dh) == 0) {
                    gray_buf = std::move(dewarped);
                    // Can't easily feed gray back to color OCR, so skip dewarp for color pipelines
                }
            }

            // OCR: use orchestrator if available, else single-shot OCR model
            int n_results = 0;
            const char * full_text = nullptr;
            float mean_conf = 0;
            const crispembed_ocr_result * results = nullptr;

            if (ocr_orch_ctx) {
                std::lock_guard<std::mutex> lock(ocr_orch_mutex);
                results =
                    crispembed_ocr_pipeline_run(ocr_orch_ctx, page_source.c_str(), &n_results, &full_text, &mean_conf);
            } else if (ocr_model_ctx) {
                std::lock_guard<std::mutex> lock(ocr_model_mutex);
                int out_len = 0;
                const char * text = crispembed_ocr_model_recognize(ocr_model_ctx, img, w, h, ch, &out_len);
                // Wrap single result
                static crispembed_ocr_result single_result;
                if (text && out_len > 0) {
                    single_result = { 0, 0, (float)w, (float)h, 1.0f, text, out_len };
                    results = &single_result;
                    n_results = 1;
                    full_text = text;
                }
            }

            stbi_image_free(img);

            // Build render page from results
            if (n_results > 0 && results) {
                total_regions += n_results;
                std::vector<ocr_render_word> words(n_results);
                std::vector<ocr_render_line> lines(n_results);
                for (int i = 0; i < n_results; i++) {
                    words[i] = { results[i].text,   (int)results[i].x, (int)results[i].y,
                                 (int)results[i].w, (int)results[i].h, results[i].confidence };
                    lines[i] = { &words[i],        1, (int)results[i].x, (int)results[i].y, (int)results[i].w,
                                 (int)results[i].h };
                }
                ocr_render_page page = { lines.data(), n_results, w, h, page_source.c_str() };
                ocr_render_add_page(renderer, &page);
            } else {
                // Empty page
                ocr_render_page page = { nullptr, 0, w, h, page_source.c_str() };
                ocr_render_add_page(renderer, &page);
            }
        }

        ocr_render_end(renderer);

        auto t1 = std::chrono::high_resolution_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        // Clean up temp files
        for (auto & tf : temp_files) std::remove(tf.c_str());

        // Return rendered document
        int out_size = ocr_render_output_size(renderer);
        const char * out_data = ocr_render_output(renderer);

        const char * content_type = "text/plain";
        if (format == "hocr")
            content_type = "text/html; charset=utf-8";
        else if (format == "alto")
            content_type = "application/xml; charset=utf-8";
        else if (format == "pdf")
            content_type = "application/pdf";

        res.set_content(std::string(out_data, out_size), content_type);
        ocr_render_free(renderer);

        fprintf(stderr, "crispembed-server: /ocr/document %zu pages, %d regions, format=%s, %.1f ms\n",
                page_paths.size(), total_regions, format.c_str(), ms);
    });

    // GET /health
    svr.Get("/health", [&](const httplib::Request &, httplib::Response & res) {
        std::ostringstream js;
        js << "{\"status\": \"ok\"";
        if (ctx) {
            js << ", \"dim\": " << dim << ", \"layers\": " << hp->n_layer << ", \"vocab\": " << hp->n_vocab;
            // "dim" stays the native size; the served default after --dim is separate.
            if (server_dim > 0 && server_dim < dim) js << ", \"output_dim\": " << server_dim;
            if (crispembed_has_decision(ctx)) js << ", \"typed_decision\": true";
            if (crispembed_has_masked_lm(ctx)) js << ", \"masked_lm\": true";
            // Retrieval capabilities of the loaded model → the matching POST routes.
            if (crispembed_is_reranker(ctx)) js << ", \"reranker\": true"; // POST /rerank + /v1/rerank
            if (crispembed_has_sparse(ctx)) js << ", \"sparse\": true";    // POST /sparse
            if (crispembed_has_colbert(ctx)) js << ", \"colbert\": true";  // POST /colbert/score
        }
        if (systemone) js << ", \"systemone\": true";
        if (moedern) js << ", \"moedern\": true";
        if (face_det) js << ", \"face_detection\": true";
        if (face_rec) js << ", \"face_recognition\": true, \"face_dim\": " << crispembed_face_dim(face_rec);
        if (vit_ctx) js << ", \"vit\": true, \"vit_dim\": " << crispembed_vit_dim(vit_ctx);
        if (clip_text_ctx)
            js << ", \"clip_text\": true, \"clip_text_dim\": " << crispembed_clip_text_dim(clip_text_ctx);
        if (ocr_model_ctx) js << ", \"ocr_model\": true, \"math_ocr\": true";
        if (ocr_pipeline_ctx) js << ", \"ocr_pipeline\": true";
        if (layout_ctx) js << ", \"layout\": true";
        if (text_det_ctx) js << ", \"text_detection\": true";
        if (ner_ctx) js << ", \"ner\": true";
        if (pix2struct_ctx) js << ", \"pix2struct\": true";
        if (ocr_orch_ctx) js << ", \"ocr_orchestrator\": true";
        if (text_sr_ctx)
            js << ", \"text_sr\": true, \"text_sr_upscale\": " << crispembed_text_sr_upscale_factor(text_sr_ctx);
        if (pan_sr_ctx) js << ", \"pan_sr\": true, \"pan_sr_upscale\": " << crispembed_pan_sr_scale(pan_sr_ctx);
        if (sam2_ctx) js << ", \"sam2\": true";
        if (hat_sr_ctx) js << ", \"hat_sr\": true, \"hat_sr_upscale\": " << crispembed_hat_sr_scale(hat_sr_ctx);
        if (dat_sr_ctx) js << ", \"dat_sr\": true";
        if (safmn_sr_ctx)
            js << ", \"safmn_sr\": true, \"safmn_sr_upscale\": " << crispembed_safmn_sr_scale(safmn_sr_ctx);
        if (esrgan_sr_ctx)
            js << ", \"esrgan_sr\": true, \"esrgan_sr_upscale\": " << crispembed_esrgan_sr_scale(esrgan_sr_ctx);
        if (swinir_sr_ctx)
            js << ", \"swinir_sr\": true, \"swinir_sr_upscale\": " << crispembed_swinir_sr_scale(swinir_sr_ctx);
        if (tbsrn_sr_ctx) js << ", \"tbsrn_sr\": true, \"tbsrn_sr_upscale\": 4";
        if (restormer_ctx) js << ", \"restormer\": true";
        if (scunet_ctx) js << ", \"scunet\": true";
        if (instructir_ctx) js << ", \"instructir\": true";
        if (adair_ctx) js << ", \"adair\": true";
        js << ", \"scan_cleanup\": true"; // always available (no model needed)
        js << "}";
        res.set_content(js.str(), "application/json");
    });

    // Runtime discovery. Every capability is reported from loaded contexts, so
    // clients can select modular routes without guessing which optional GGUF
    // backends are present.
    svr.Get("/capabilities", [&](const httplib::Request &, httplib::Response & res) {
        crispembed_ocr_capabilities oc{};
        const bool have_orch_caps = ocr_orch_ctx && crispembed_ocr_pipeline_capabilities(ocr_orch_ctx, &oc);
        std::ostringstream js;
        js << "{\"status\":\"ok\",\"routes\":{";
        js << "\"systemone\":" << (systemone ? "true" : "false") << ",";
        js << "\"moedern\":" << (moedern ? "true" : "false") << ",";
        js << "\"ocr\":" << (ocr_pipeline_ctx ? "true" : "false");
        js << ",\"ocr_pipeline\":" << (ocr_orch_ctx ? "true" : "false");
        js << ",\"layout\":" << (layout_ctx || (have_orch_caps && oc.layout) ? "true" : "false");
        js << ",\"tables\":" << (have_orch_caps && oc.tables ? "true" : "false");
        js << ",\"formulas\":" << (have_orch_caps && oc.formulas ? "true" : "false");
        js << ",\"batch\":true,\"markdown\":" << (ocr_orch_ctx ? "true" : "false") << "}";
        js << ",\"modules\":{";
        js << "\"generic_ocr\":" << (ocr_model_ctx ? "true" : "false");
        js << ",\"dbnet_trocr\":" << (ocr_pipeline_ctx || ocr_orch_ctx ? "true" : "false");
        js << ",\"tesseract_lstm\":" << ((ocr_model_ctx || (have_orch_caps && oc.tables)) ? "true" : "false");
        js << ",\"layout_detector\":" << (layout_ctx || (have_orch_caps && oc.layout) ? "true" : "false");
        js << ",\"vlm_escalation\":" << (!vlm_model_path.empty() ? "true" : "false");
        js << "},\"config\":{";
        js << "\"route_tables\":" << (route_tables ? "true" : "false");
        js << ",\"route_formulas\":" << (route_formulas ? "true" : "false");
        js << ",\"pooling\":false";
        js << "}}";
        res.set_content(js.str(), "application/json");
    });

    svr.Get("/health/live", [&](const httplib::Request &, httplib::Response & res) {
        res.status = 200;
        res.set_content("{\"status\":\"live\"}", "application/json");
    });

    svr.Get("/health/ready", [&](const httplib::Request &, httplib::Response & res) {
        const bool ready = systemone || moedern || ctx || face_det || vit_ctx || ocr_model_ctx || ocr_pipeline_ctx ||
                           ocr_orch_ctx || layout_ctx || text_det_ctx || ner_ctx || pix2struct_ctx;
        res.status = ready ? 200 : 503;
        res.set_content(ready ? "{\"status\":\"ready\"}" : "{\"status\":\"not_ready\"}", "application/json");
    });

    fprintf(stderr, "\ncrispembed-server: listening on %s:%d\n", host.c_str(), port);
    if (ctx) {
        fprintf(stderr, "  POST /embed           — {\"texts\": [\"hello\"]}\n");
        fprintf(stderr, "  POST /v1/embeddings   — OpenAI-compatible\n");
        fprintf(stderr, "  POST /api/embed       — Ollama-compatible\n");
        fprintf(stderr, "  POST /api/embeddings  — Ollama-compatible (legacy)\n");
    }
    if (face_det) fprintf(stderr, "  POST /detect          — {\"image\": \"path.jpg\"}\n");
    if (face_det && face_rec) fprintf(stderr, "  POST /face            — {\"image\": \"path.jpg\"} (pipeline)\n");
    if (vit_ctx) fprintf(stderr, "  POST /vit/encode      — {\"image\": \"path.jpg\"}\n");
    if (clip_text_ctx) fprintf(stderr, "  POST /clip/text       — {\"text\": \"query\"}\n");
    if (pix2struct_ctx)
        fprintf(stderr, "  POST /pix2struct/generate — {\"image\": \"doc.png\", \"max_tokens\": 256}\n");
    if (marker_ctx) fprintf(stderr, "  POST /ocr/marker      — {\"file\": \"doc.pdf\", \"format\": \"json\"}\n");
    if (ocr_model_ctx) fprintf(stderr, "  POST /ocr/model       — {\"image\": \"formula.png\"}  (alias: /math/ocr)\n");
    if (ocr_pipeline_ctx)
        fprintf(stderr, "  POST /ocr             — {\"image\": \"document.png\"} (detect+recognize)\n");
    if (layout_ctx) fprintf(stderr, "  POST /layout/detect   — {\"image\": \"page.png\"}\n");
    fprintf(stderr, "  POST /table/parse     — {\"image\": \"table.png\"} → {\"html\": \"<table>...\"}\n");
    if (text_det_ctx) fprintf(stderr, "  POST /text/detect     — {\"image\": \"page.png\"}\n");
    if (ner_ctx) fprintf(stderr, "  POST /ner/extract     — {\"text\": \"...\", \"labels\": [\"person\", ...]}\n");
#if SERVER_HAS_LID
    if (lid_ctx)
        fprintf(stderr, "  POST /lid/detect      — {\"text\": \"...\"} → {\"lang\": \"de\", \"confidence\": 0.99}\n");
#endif
    if (kie_ctx)
        fprintf(stderr, "  POST /kie/extract     — {\"image\": \"doc.png\", \"labels\": [\"total\", ...]} (OCR+NER)\n");
    if (ocr_orch_ctx)
        fprintf(stderr, "  POST /ocr/pipeline    — {\"image\": \"doc.png\"} (routing + cleanup + accept-gate)\n");
    if (text_sr_ctx)
        fprintf(stderr, "  POST /text/sr         — {\"image\": \"low_dpi.png\"} (upscale %dx)\n",
                crispembed_text_sr_upscale_factor(text_sr_ctx));
    if (pan_sr_ctx)
        fprintf(stderr, "  POST /pan/sr          — {\"image\": \"photo.png\"} (upscale %dx)\n",
                crispembed_pan_sr_scale(pan_sr_ctx));
    if (sam2_ctx)
        fprintf(stderr, "  POST /sam2/segment    — {\"image\": \"photo.png\", \"points\": [[x, y, 1]], \"box\": [x0, "
                        "y0, x1, y1]}\n");
    if (hat_sr_ctx)
        fprintf(stderr, "  POST /hat/sr          — {\"image\": \"photo.png\"} (upscale %dx)\n",
                crispembed_hat_sr_scale(hat_sr_ctx));
    if (dat_sr_ctx) fprintf(stderr, "  POST /dat/sr          — {\"image\": \"photo.png\"} (upscale 2x)\n");
    if (safmn_sr_ctx)
        fprintf(stderr, "  POST /safmn/sr        — {\"image\": \"photo.png\"} (upscale %dx)\n",
                crispembed_safmn_sr_scale(safmn_sr_ctx));
    if (esrgan_sr_ctx)
        fprintf(stderr, "  POST /esrgan/sr       — {\"image\": \"photo.png\"} (upscale %dx)\n",
                crispembed_esrgan_sr_scale(esrgan_sr_ctx));
    if (swinir_sr_ctx)
        fprintf(stderr, "  POST /swinir/sr       — {\"image\": \"photo.png\"} (upscale %dx)\n",
                crispembed_swinir_sr_scale(swinir_sr_ctx));
    if (tbsrn_sr_ctx) fprintf(stderr, "  POST /tbsrn/sr        — {\"image\": \"text_line.png\"} (upscale 4x)\n");
    if (restormer_ctx) fprintf(stderr, "  POST /restormer       — {\"image\": \"noisy.png\"} (denoise/restore)\n");
    if (scunet_ctx) fprintf(stderr, "  POST /scunet/denoise  — {\"image\": \"noisy.png\"} (Swin-Conv-UNet denoise)\n");
    if (instructir_ctx)
        fprintf(stderr, "  POST /instructir/restore — {\"image\": \"...\", \"task\": 0} (all-in-one restoration)\n");
    if (adair_ctx)
        fprintf(stderr, "  POST /adair/restore     — {\"image\": \"noisy.png\"} (Restormer+AFLB+FFT restore)\n");
    fprintf(stderr, "  POST /scan/cleanup    — {\"image\": \"scan.png\"} (deskew, crop, whiten)\n");
    fprintf(stderr, "  POST /pdf/dpi              — {\"file\": \"...\"} (PDF DPI profiling)\n");
    fprintf(stderr, "  POST /preprocess/skew      — {\"image\": \"...\"} (find skew angle)\n");
    fprintf(stderr, "  POST /preprocess/orientation — {\"image\": \"...\"} (four-way orientation advisory)\n");
    fprintf(stderr, "  POST /preprocess/dewarp    — {\"image\": \"...\"} (straighten curved text)\n");
    fprintf(stderr, "  POST /preprocess/tps-dewarp — {\"image\": \"...\", \"model\": \"tps-loc.gguf\"}\n");
    fprintf(stderr, "  POST /preprocess/cc-detect — {\"image\": \"...\"} (model-free line detection)\n");
    fprintf(stderr, "  POST /render/ocr           — {\"results\": [...], \"format\": \"hocr|alto|pdf\"}\n");
    fprintf(stderr, "  POST /ocr/document         — multi-page OCR → searchable PDF/hOCR/text (upload or paths)\n");
    if (ctx) fprintf(stderr, "  POST /tokens          — raw or normalized token embeddings and IDs\n");
    if (ctx && crispembed_has_decision(ctx))
        fprintf(stderr, "  POST /decide          — {state, questions, workflow?} typed answers\n");
    if (ctx && crispembed_has_masked_lm(ctx)) {
        fprintf(stderr, "  POST /fill-mask       — {\"text\": \"... [MASK] ...\", \"top_k\": 5}\n");
        fprintf(stderr, "  POST /masked-logits   — raw logits for all mask positions\n");
    }
    if (ctx && crispembed_has_colbert(ctx))
        fprintf(stderr, "  POST /colbert/score   — {\"query\": \"...\", \"documents\": [...]}\n");
    if (ctx && crispembed_is_reranker(ctx)) {
        fprintf(stderr, "  POST /rerank          — {\"query\": \"...\", \"documents\": [...], \"top_n\": 10}\n");
        fprintf(stderr, "  POST /v1/rerank       — Cohere/Jina shape: sigmoid relevance_score, "
                        "\"return_documents\": true to echo text\n");
    }
    if (ctx && crispembed_has_sparse(ctx))
        fprintf(stderr, "  POST /sparse          — {\"texts\": [\"...\"]}  (SPLADE/BGE-M3 term weights)\n");
    fprintf(stderr, "  GET  /health\n\n");

    svr.listen(host, port);

    if (kie_ctx) crispembed_kie_free(kie_ctx);
    if (text_sr_ctx) crispembed_text_sr_free(text_sr_ctx);
    if (pan_sr_ctx) crispembed_pan_sr_free(pan_sr_ctx);
    if (sam2_ctx) crispembed_sam2_free(sam2_ctx);
    if (hat_sr_ctx) crispembed_hat_sr_free(hat_sr_ctx);
    if (dat_sr_ctx) crispembed_dat_sr_free(dat_sr_ctx);
    if (safmn_sr_ctx) crispembed_safmn_sr_free(safmn_sr_ctx);
    if (esrgan_sr_ctx) crispembed_esrgan_sr_free(esrgan_sr_ctx);
    if (swinir_sr_ctx) crispembed_swinir_sr_free(swinir_sr_ctx);
    if (tbsrn_sr_ctx) crispembed_tbsrn_sr_free(tbsrn_sr_ctx);
    if (restormer_ctx) crispembed_restormer_free(restormer_ctx);
    if (scunet_ctx) crispembed_scunet_free(scunet_ctx);
    if (adair_ctx) crispembed_adair_free(adair_ctx);
    if (instructir_ctx) crispembed_instructir_free(instructir_ctx);
    if (ner_ctx) crispembed_ner_free(ner_ctx);
#if SERVER_HAS_LID
    if (lid_ctx) text_lid_free(lid_ctx);
#endif
    if (layout_ctx) crispembed_layout_free(layout_ctx);
    if (text_det_ctx) crispembed_text_det_free(text_det_ctx);
    if (ocr_orch_ctx) crispembed_ocr_pipeline_free(ocr_orch_ctx);
    if (ocr_pipeline_ctx) crispembed_ocr_free(ocr_pipeline_ctx);
    if (ocr_model_ctx) crispembed_ocr_model_free(ocr_model_ctx);
    if (marker_ctx) crispembed_marker_free(marker_ctx);
    if (clip_text_ctx) crispembed_clip_text_free(clip_text_ctx);
    if (vit_ctx) crispembed_vit_free(vit_ctx);
    if (pix2struct_ctx) crispembed_pix2struct_free(pix2struct_ctx);
    if (face_det) crispembed_face_free(face_det);
    if (face_rec) crispembed_face_free(face_rec);
    if (ctx) crispembed_free(ctx);
    return 0;
}
